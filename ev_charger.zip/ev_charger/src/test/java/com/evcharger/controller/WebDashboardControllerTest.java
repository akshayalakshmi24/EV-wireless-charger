package com.evcharger.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Spring MockMvc tests verifying the 5 web pages, form submission, CSV export endpoint,
 * and REST API responses.
 */
@SpringBootTest
@AutoConfigureMockMvc
class WebDashboardControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Page 1: Dashboard renders with AUTO-TRIGGER EV CHARGER title and summary model")
    void testDashboardPageRenders() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("summary", "recentSessions"))
                .andExpect(content().string(containsString("AUTO-TRIGGER EV CHARGER")));
    }

    @Test
    @DisplayName("Page 2: New Charging Session form renders and processes valid submission")
    void testNewSessionFormAndPost() throws Exception {
        mockMvc.perform(get("/session/new"))
                .andExpect(status().isOk())
                .andExpect(view().name("new-session"))
                .andExpect(content().string(containsString("Detect EV &amp; Start Automatic Charging")));

        mockMvc.perform(post("/session/new")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("evId", "EV-2W-901")
                        .param("vehicleType", "TWO_WHEELER")
                        .param("startBatteryPct", "25")
                        .param("targetBatteryPct", "85")
                        .param("temperatureC", "31.0")
                        .param("alignmentStatus", "GOOD")
                        .param("energySource", "SOLAR_GRID"))
                .andExpect(status().isOk())
                .andExpect(view().name("new-session"))
                .andExpect(model().attributeExists("savedSession", "calcResult"))
                .andExpect(content().string(containsString("EV detected")))
                .andExpect(content().string(containsString("Alignment check passed")))
                .andExpect(content().string(containsString("Charging completed")));
    }

    @Test
    @DisplayName("Page 3, 4, 5: History, Analytics, Export pages and CSV download endpoint respond 200 OK")
    void testHistoryAnalyticsAndCsvDownload() throws Exception {
        mockMvc.perform(get("/history"))
                .andExpect(status().isOk())
                .andExpect(view().name("history"));

        mockMvc.perform(get("/analytics"))
                .andExpect(status().isOk())
                .andExpect(view().name("analytics"))
                .andExpect(model().attributeExists("analytics"));

        mockMvc.perform(get("/export"))
                .andExpect(status().isOk())
                .andExpect(view().name("export"))
                .andExpect(content().string(containsString("Export Charging Data to CSV")));

        mockMvc.perform(get("/export/csv"))
                .andExpect(status().isOk())
                .andExpect(header().string("Content-Disposition", containsString("ev_charging_sessions.csv")))
                .andExpect(content().string(containsString(
                        "Session_ID,EV_ID,Vehicle_Type,Start_Battery_pct,Target_Battery_pct,End_Battery_pct,Temperature_C,Alignment_Status,Charging_Time_min,Energy_Consumed_kWh,Charging_Efficiency_pct,Energy_Source,Status,Session_Timestamp"
                )));
    }
}
