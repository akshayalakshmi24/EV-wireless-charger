package com.evcharger.service;

import com.evcharger.dto.AnalyticsSummaryDto;
import com.evcharger.dto.ChargingSessionRequestDto;
import com.evcharger.dto.DashboardSummaryDto;
import com.evcharger.entity.ChargingSession;
import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.EnergySource;
import com.evcharger.model.VehicleType;
import com.evcharger.repository.ChargingSessionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Comprehensive JUnit 5 integration and unit tests verifying essential business rules:
 * <ul>
 *     <li>Valid charging session &amp; completed session metrics</li>
 *     <li>Poor coil alignment blocking &amp; persistence</li>
 *     <li>Excessive simulated temperature blocking &amp; thermal warning</li>
 *     <li>Invalid battery values &amp; target battery not greater than starting battery</li>
 *     <li>CSV export format, header columns, and field escaping</li>
 *     <li>Dashboard &amp; Analytics dynamic database statistics</li>
 * </ul>
 */
@SpringBootTest
class ChargingServiceTest {

    @Autowired
    private ChargingService chargingService;

    @Autowired
    private SessionDataService sessionDataService;

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private CSVExportService csvExportService;

    @Autowired
    private ChargingSessionRepository sessionRepository;

    @BeforeEach
    void cleanDatabase() {
        sessionRepository.deleteAll();
    }

    @Test
    @DisplayName("1. Valid charging session initiates automatically and completes with positive energy & duration")
    void testValidCompletedChargingSession() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-2W-101",
                VehicleType.TWO_WHEELER,
                20,
                80,
                28.5,
                AlignmentStatus.GOOD,
                EnergySource.SOLAR_GRID
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        ChargingSession saved = outcome.getSession();

        assertThat(saved.getSessionId()).isNotNull();
        assertThat(saved.getStatus()).isEqualTo(ChargingStatus.COMPLETED);
        assertThat(saved.getStartBatteryPct()).isEqualTo(20);
        assertThat(saved.getEndBatteryPct()).isEqualTo(80);
        assertThat(saved.getChargingTimeMin()).isGreaterThan(0.0);
        // 60% of 3.2 kWh = 1.92 kWh net delivered to battery
        assertThat(saved.getEnergyDeliveredKwh()).isEqualTo(1.92);
        // Source consumed energy must exceed net delivered energy due to wireless transfer losses
        assertThat(saved.getEnergyConsumedKwh()).isGreaterThan(saved.getEnergyDeliveredKwh());
        assertThat(saved.getChargingEfficiencyPct()).isBetween(85.0, 96.0);

        List<String> logs = outcome.getCalculationResult().getWorkflowLogs();
        assertThat(logs).anyMatch(msg -> msg.contains("EV detected"));
        assertThat(logs).anyMatch(msg -> msg.contains("Alignment check passed"));
        assertThat(logs).anyMatch(msg -> msg.contains("Charging started"));
        assertThat(logs).anyMatch(msg -> msg.contains("Charging completed"));
    }

    @Test
    @DisplayName("2. Poor coil alignment blocks charging and persists blocked attempt with zero energy")
    void testPoorAlignmentBlocksCharging() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-2W-202",
                VehicleType.TWO_WHEELER,
                30,
                85,
                30.0,
                AlignmentStatus.POOR,
                EnergySource.GRID
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        ChargingSession saved = outcome.getSession();

        assertThat(saved.getSessionId()).isNotNull();
        assertThat(saved.getStatus()).isEqualTo(ChargingStatus.BLOCKED_ALIGNMENT);
        assertThat(saved.getEndBatteryPct()).isEqualTo(30);
        assertThat(saved.getChargingTimeMin()).isEqualTo(0.0);
        assertThat(saved.getEnergyConsumedKwh()).isEqualTo(0.0);
        assertThat(saved.getChargingEfficiencyPct()).isEqualTo(0.0);
        assertThat(saved.getStatusMessage()).contains("Charging blocked due to poor alignment");
    }

    @Test
    @DisplayName("3. Excessive simulated temperature (> 45 C) blocks charging and saves BLOCKED_TEMPERATURE record")
    void testExcessiveTemperatureBlocksCharging() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-3W-303",
                VehicleType.THREE_WHEELER,
                25,
                90,
                49.2,
                AlignmentStatus.GOOD,
                EnergySource.SOLAR
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        ChargingSession saved = outcome.getSession();

        assertThat(saved.getSessionId()).isNotNull();
        assertThat(saved.getStatus()).isEqualTo(ChargingStatus.BLOCKED_TEMPERATURE);
        assertThat(saved.getEndBatteryPct()).isEqualTo(25);
        assertThat(saved.getChargingTimeMin()).isEqualTo(0.0);
        assertThat(saved.getEnergyConsumedKwh()).isEqualTo(0.0);
        assertThat(saved.getStatusMessage()).contains("Charging blocked due to excessive temperature");
    }

    @Test
    @DisplayName("4. Elevated temperature (40 C to 45 C) triggers thermal warning but completes charging")
    void testElevatedTemperatureWarningCompletesCharging() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-3W-309",
                VehicleType.THREE_WHEELER,
                40,
                80,
                42.5,
                AlignmentStatus.GOOD,
                EnergySource.SOLAR
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        assertThat(outcome.getSession().getStatus()).isEqualTo(ChargingStatus.COMPLETED);
        assertThat(outcome.getCalculationResult().isTemperatureWarning()).isTrue();
        assertThat(outcome.getCalculationResult().getWorkflowLogs())
                .anyMatch(msg -> msg.contains("Temperature warning"));
    }

    @Test
    @DisplayName("5. Invalid battery values (< 0 or > 100) are blocked with FAULT status and never produce negative energy")
    void testInvalidBatteryValuesBlocked() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-2W-404",
                VehicleType.TWO_WHEELER,
                -5,
                85,
                29.0,
                AlignmentStatus.GOOD,
                EnergySource.GRID
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        ChargingSession saved = outcome.getSession();

        assertThat(saved.getStatus()).isEqualTo(ChargingStatus.FAULT);
        assertThat(saved.getChargingTimeMin()).isEqualTo(0.0);
        assertThat(saved.getEnergyConsumedKwh()).isEqualTo(0.0);
    }

    @Test
    @DisplayName("6. Target battery not greater than starting battery is blocked and persisted as FAULT")
    void testTargetBatteryNotGreaterThanStartBatteryBlocked() {
        ChargingSessionRequestDto request = new ChargingSessionRequestDto(
                "EV-2W-505",
                VehicleType.TWO_WHEELER,
                75,
                60,
                29.0,
                AlignmentStatus.GOOD,
                EnergySource.SOLAR
        );

        ChargingService.SessionExecutionOutcome outcome = chargingService.detectAndTriggerCharging(request);
        ChargingSession saved = outcome.getSession();

        assertThat(saved.getSessionId()).isNotNull();
        assertThat(saved.getStatus()).isEqualTo(ChargingStatus.FAULT);
        assertThat(saved.getEndBatteryPct()).isEqualTo(75);
        assertThat(saved.getChargingTimeMin()).isEqualTo(0.0);
        assertThat(saved.getEnergyConsumedKwh()).isEqualTo(0.0);
        assertThat(saved.getStatusMessage()).contains("must be strictly greater than starting battery percentage");
    }

    @Test
    @DisplayName("7. CSV Export contains exact required headers and properly formats records")
    void testCsvExportHeadersAndFormatting() {
        chargingService.detectAndTriggerCharging(new ChargingSessionRequestDto(
                "EV-2W-701", VehicleType.TWO_WHEELER, 25, 85, 30.0, AlignmentStatus.GOOD, EnergySource.SOLAR
        ));
        chargingService.detectAndTriggerCharging(new ChargingSessionRequestDto(
                "EV-3W-702", VehicleType.THREE_WHEELER, 40, 90, 32.0, AlignmentStatus.POOR, EnergySource.GRID
        ));

        String csv = csvExportService.exportAllSessionsToCsvString();
        String[] lines = csv.split("\r\n");

        assertThat(lines).hasSize(3);
        assertThat(lines[0]).isEqualTo(
                "Session_ID,EV_ID,Vehicle_Type,Start_Battery_pct,Target_Battery_pct,End_Battery_pct," +
                "Temperature_C,Alignment_Status,Charging_Time_min,Energy_Consumed_kWh," +
                "Charging_Efficiency_pct,Energy_Source,Status,Session_Timestamp"
        );
        assertThat(lines[1]).contains("EV-2W-701,2-Wheeler,25,85,85,30.0,Good");
        assertThat(lines[1]).contains("Solar,COMPLETED");
        assertThat(lines[2]).contains("EV-3W-702,3-Wheeler,40,90,40,32.0,Poor,0.0,0.000,0.00,Grid,BLOCKED_ALIGNMENT");
    }

    @Test
    @DisplayName("8. Dashboard and Analytics statistics are accurately computed from database records")
    void testDashboardAndAnalyticsStatistics() {
        // 2 successful sessions + 1 blocked session
        chargingService.detectAndTriggerCharging(new ChargingSessionRequestDto(
                "EV-2W-801", VehicleType.TWO_WHEELER, 20, 80, 25.0, AlignmentStatus.GOOD, EnergySource.SOLAR
        ));
        chargingService.detectAndTriggerCharging(new ChargingSessionRequestDto(
                "EV-3W-802", VehicleType.THREE_WHEELER, 40, 80, 30.0, AlignmentStatus.GOOD, EnergySource.GRID
        ));
        chargingService.detectAndTriggerCharging(new ChargingSessionRequestDto(
                "EV-2W-803", VehicleType.TWO_WHEELER, 30, 90, 48.0, AlignmentStatus.GOOD, EnergySource.SOLAR_GRID
        ));

        DashboardSummaryDto summary = dashboardService.buildDashboardSummary();

        assertThat(summary.getTotalSessions()).isEqualTo(3);
        assertThat(summary.getSuccessfulSessions()).isEqualTo(2);
        assertThat(summary.getBlockedOrFailedSessions()).isEqualTo(1);
        assertThat(summary.getAvgStartBatteryPct()).isEqualTo(30.0); // (20 + 40 + 30) / 3 = 30.0
        assertThat(summary.getTotalEnergyConsumedKwh()).isGreaterThan(4.9);
        assertThat(summary.getAvgChargingTimeMin()).isGreaterThan(0.0);

        AnalyticsSummaryDto analytics = dashboardService.buildAnalyticsSummary();
        assertThat(analytics.getTotalSessions()).isEqualTo(3);
        assertThat(analytics.getCompletedSessions()).isEqualTo(2);
        assertThat(analytics.getDescriptiveStats()).hasSize(5);
        assertThat(analytics.getTemperatureEfficiencyPoints()).hasSize(2);
    }

    @Test
    @DisplayName("9. Synthetic 100-session generator produces 100 reproducible records with zero contradictions")
    void testGenerate100DemoSessionsReproducibility() {
        int count = sessionDataService.generateReproducibleDemoSessions(100, true);
        assertThat(count).isEqualTo(100);

        List<ChargingSession> all = sessionDataService.getAllSessionsChronological();
        assertThat(all).hasSize(100);

        for (ChargingSession s : all) {
            if (s.getStatus() == ChargingStatus.COMPLETED) {
                assertThat(s.getAlignmentStatus()).isEqualTo(AlignmentStatus.GOOD);
                assertThat(s.getTemperatureC()).isLessThanOrEqualTo(45.0);
                assertThat(s.getEndBatteryPct()).isEqualTo(s.getTargetBatteryPct());
                assertThat(s.getChargingTimeMin()).isGreaterThan(0.0);
                assertThat(s.getEnergyConsumedKwh()).isGreaterThan(0.0);
            } else {
                assertThat(s.getChargingTimeMin()).isEqualTo(0.0);
                assertThat(s.getEnergyConsumedKwh()).isEqualTo(0.0);
                assertThat(s.getEndBatteryPct()).isEqualTo(s.getStartBatteryPct());
            }
        }
    }
}
