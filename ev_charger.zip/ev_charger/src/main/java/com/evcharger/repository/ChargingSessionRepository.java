package com.evcharger.repository;

import com.evcharger.entity.ChargingSession;
import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.VehicleType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data JPA Repository for {@link ChargingSession} entities.
 */
@Repository
public interface ChargingSessionRepository extends JpaRepository<ChargingSession, Long> {

    /**
     * Returns all sessions ordered newest first (for history and dashboard tables).
     */
    List<ChargingSession> findAllByOrderBySessionTimestampDesc();

    /**
     * Returns all sessions ordered by sessionId ascending (useful for chronological CSV export).
     */
    List<ChargingSession> findAllByOrderBySessionIdAsc();

    /**
     * Returns the 8 most recent charging sessions for the Dashboard overview table.
     */
    List<ChargingSession> findTop8ByOrderBySessionTimestampDesc();

    /**
     * Counts how many synthetic demo sessions currently exist in the database.
     */
    long countBySyntheticDemoTrue();

    /**
     * Deletes synthetic demo sessions when regenerating a clean demo batch.
     */
    void deleteBySyntheticDemoTrue();

    /**
     * Finds sessions matching a specific ChargingStatus.
     */
    List<ChargingSession> findByStatusOrderBySessionTimestampDesc(ChargingStatus status);

    /**
     * Finds sessions matching a specific VehicleType.
     */
    List<ChargingSession> findByVehicleTypeOrderBySessionTimestampDesc(VehicleType vehicleType);

    /**
     * Finds sessions matching a specific AlignmentStatus.
     */
    List<ChargingSession> findByAlignmentStatusOrderBySessionTimestampDesc(AlignmentStatus alignmentStatus);
}
