package com.evcharger.exception;

/**
 * Custom exception thrown when charging simulation parameters are invalid
 * or cannot be parsed.
 */
public class InvalidChargingParameterException extends RuntimeException {

    public InvalidChargingParameterException(String message) {
        super(message);
    }

    public InvalidChargingParameterException(String message, Throwable cause) {
        super(message, cause);
    }
}
