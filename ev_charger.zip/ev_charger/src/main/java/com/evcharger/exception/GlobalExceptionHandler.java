package com.evcharger.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Centralized exception handler for both Spring MVC views and REST API endpoints.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SessionNotFoundException.class)
    public Object handleSessionNotFound(SessionNotFoundException ex,
                                        HttpServletRequest request,
                                        Model model) {
        if (isApiRequest(request)) {
            return buildJsonError(HttpStatus.NOT_FOUND, ex.getMessage(), request.getRequestURI());
        }
        model.addAttribute("errorTitle", "Session Not Found");
        model.addAttribute("errorMessage", ex.getMessage());
        model.addAttribute("activePage", "history");
        return "error";
    }

    @ExceptionHandler(InvalidChargingParameterException.class)
    public Object handleInvalidChargingParameter(InvalidChargingParameterException ex,
                                                 HttpServletRequest request,
                                                 Model model) {
        if (isApiRequest(request)) {
            return buildJsonError(HttpStatus.BAD_REQUEST, ex.getMessage(), request.getRequestURI());
        }
        model.addAttribute("errorTitle", "Invalid Simulation Parameter");
        model.addAttribute("errorMessage", ex.getMessage());
        model.addAttribute("activePage", "new-session");
        return "error";
    }

    @ExceptionHandler(Exception.class)
    public Object handleGenericException(Exception ex,
                                         HttpServletRequest request,
                                         Model model) {
        if (isApiRequest(request)) {
            return buildJsonError(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unexpected error: " + ex.getMessage(), request.getRequestURI());
        }
        model.addAttribute("errorTitle", "Application Error");
        model.addAttribute("errorMessage", ex.getMessage());
        model.addAttribute("activePage", "dashboard");
        return "error";
    }

    private boolean isApiRequest(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri != null && uri.startsWith("/api/");
    }

    private ResponseEntity<Map<String, Object>> buildJsonError(HttpStatus status,
                                                               String message,
                                                               String path) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("message", message);
        body.put("path", path);
        return ResponseEntity.status(status).body(body);
    }
}
