package com.evcharger.exception;

/**
 * Custom exception thrown when a requested ChargingSession ID does not exist
 * in the database.
 */
public class SessionNotFoundException extends RuntimeException {

    public SessionNotFoundException(Long sessionId) {
        super("Charging session with ID " + sessionId + " was not found.");
    }

    public SessionNotFoundException(String message) {
        super(message);
    }
}
