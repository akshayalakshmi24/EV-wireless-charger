package com.evcharger.model;

/**
 * Abstract base class for pre-charging condition monitors.
 *
 * <p>Demonstrates inheritance in Java by providing shared naming and helper
 * methods to concrete monitors ({@link AlignmentMonitor}, {@link TemperatureMonitor},
 * and {@link BatteryMonitor}).</p>
 */
public abstract class AbstractConditionMonitor implements ConditionMonitor {

    private final String monitorName;

    protected AbstractConditionMonitor(String monitorName) {
        this.monitorName = monitorName;
    }

    @Override
    public String getMonitorName() {
        return monitorName;
    }

    protected MonitorCheckResult pass(String message) {
        return MonitorCheckResult.pass(monitorName, message);
    }

    protected MonitorCheckResult warn(String message) {
        return MonitorCheckResult.warn(monitorName, message);
    }

    protected MonitorCheckResult block(String message, ChargingStatus status) {
        return MonitorCheckResult.block(monitorName, message, status);
    }
}
