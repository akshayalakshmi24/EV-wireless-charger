package com.evcharger.model;

/**
 * Enum representing the target electric vehicle categories supported by the
 * Auto-Trigger Portable Wireless EV Charger.
 */
public enum VehicleType {

    TWO_WHEELER("2-Wheeler", 3.2),
    THREE_WHEELER("3-Wheeler", 7.5);

    private final String displayName;
    private final double defaultCapacityKwh;

    VehicleType(String displayName, double defaultCapacityKwh) {
        this.displayName = displayName;
        this.defaultCapacityKwh = defaultCapacityKwh;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getDefaultCapacityKwh() {
        return defaultCapacityKwh;
    }

    /**
     * Resolves a VehicleType from a display name or enum constant string.
     */
    public static VehicleType fromString(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Vehicle type cannot be empty.");
        }
        String normalized = value.trim();
        for (VehicleType type : values()) {
            if (type.name().equalsIgnoreCase(normalized)
                    || type.displayName.equalsIgnoreCase(normalized)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unsupported vehicle type: " + value);
    }
}
