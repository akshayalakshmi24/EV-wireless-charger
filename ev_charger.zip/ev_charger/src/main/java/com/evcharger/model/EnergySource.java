package com.evcharger.model;

/**
 * Enum representing the input power supply source for the portable wireless charger.
 */
public enum EnergySource {

    SOLAR("Solar"),
    GRID("Grid"),
    SOLAR_GRID("Solar + Grid");

    private final String displayName;

    EnergySource(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static EnergySource fromString(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Energy source cannot be empty.");
        }
        String normalized = value.trim();
        for (EnergySource source : values()) {
            if (source.name().equalsIgnoreCase(normalized)
                    || source.displayName.equalsIgnoreCase(normalized)) {
                return source;
            }
        }
        throw new IllegalArgumentException("Unsupported energy source: " + value);
    }
}
