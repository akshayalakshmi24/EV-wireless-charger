package com.evcharger.model;

/**
 * Enum representing the simulated inductive coil alignment status between
 * the portable ground transmitter pad and the EV receiver pad.
 */
public enum AlignmentStatus {

    GOOD("Good", true),
    POOR("Poor", false);

    private final String displayName;
    private final boolean acceptableForCharging;

    AlignmentStatus(String displayName, boolean acceptableForCharging) {
        this.displayName = displayName;
        this.acceptableForCharging = acceptableForCharging;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isAcceptableForCharging() {
        return acceptableForCharging;
    }

    public static AlignmentStatus fromString(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Alignment status cannot be empty.");
        }
        String normalized = value.trim();
        for (AlignmentStatus status : values()) {
            if (status.name().equalsIgnoreCase(normalized)
                    || status.displayName.equalsIgnoreCase(normalized)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unsupported alignment status: " + value);
    }
}
