package com.evcharger.model;

import org.springframework.stereotype.Component;

/**
 * Monitors and validates EV starting and target battery state-of-charge (SoC) percentages.
 */
@Component
public class BatteryMonitor extends AbstractConditionMonitor {

    public BatteryMonitor() {
        super("Battery SoC Monitor");
    }

    @Override
    public MonitorCheckResult evaluate(EV ev, PortableCharger charger) {
        int startPct = ev.getStartBatteryPct();
        int targetPct = ev.getTargetBatteryPct();

        if (startPct < 0 || startPct > 99) {
            return block(
                    "Invalid battery state: Starting battery percentage (" + startPct + "%) must be between 0% and 99%.",
                    ChargingStatus.FAULT
            );
        }

        if (targetPct < 1 || targetPct > 100) {
            return block(
                    "Invalid battery state: Target battery percentage (" + targetPct + "%) must be between 1% and 100%.",
                    ChargingStatus.FAULT
            );
        }

        if (targetPct <= startPct) {
            return block(
                    "Charging blocked: Target battery percentage (" + targetPct
                            + "%) must be strictly greater than starting battery percentage (" + startPct + "%).",
                    ChargingStatus.FAULT
            );
        }

        return pass(
                "Battery SoC check passed: Charging requested from " + startPct + "% to " + targetPct
                        + "% (+" + ev.getRequestedBatteryDeltaPct() + "% SoC)."
        );
    }
}
