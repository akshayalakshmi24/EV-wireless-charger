package com.evcharger.model;

import com.evcharger.config.SimulationProperties;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * Monitors simulated ambient and coil pad temperature against configurable
 * demonstration thresholds.
 *
 * <p>Note: Thresholds are configurable software simulation parameters rather
 * than certified hardware thermal cutoff limits.</p>
 */
@Component
public class TemperatureMonitor extends AbstractConditionMonitor {

    private final SimulationProperties simulationProperties;

    public TemperatureMonitor(SimulationProperties simulationProperties) {
        super("Thermal Safety Monitor");
        this.simulationProperties = simulationProperties;
    }

    @Override
    public MonitorCheckResult evaluate(EV ev, PortableCharger charger) {
        double tempC = charger.getSimulatedTemperatureC();
        double maxTemp = simulationProperties.getMaxTemperatureC();
        double warnTemp = simulationProperties.getWarningTemperatureC();
        double minTemp = simulationProperties.getMinTemperatureC();

        if (tempC < minTemp) {
            return block(
                    String.format(Locale.US,
                            "Temperature fault: Simulated temperature (%.1f °C) is below minimum operational threshold (%.1f °C).",
                            tempC, minTemp),
                    ChargingStatus.BLOCKED_TEMPERATURE
            );
        }

        if (tempC > maxTemp) {
            return block(
                    String.format(Locale.US,
                            "Temperature warning / Cutoff: Simulated temperature (%.1f °C) exceeds demonstration threshold (%.1f °C). Charging blocked due to excessive temperature.",
                            tempC, maxTemp),
                    ChargingStatus.BLOCKED_TEMPERATURE
            );
        }

        if (tempC >= warnTemp) {
            return warn(
                    String.format(Locale.US,
                            "Temperature warning: Simulated temperature (%.1f °C) is elevated (>= %.1f °C) but within safe simulation limit (<= %.1f °C). Thermal derating applied.",
                            tempC, warnTemp, maxTemp)
            );
        }

        return pass(
                String.format(Locale.US,
                        "Thermal check passed: Simulated temperature (%.1f °C) is within optimal operating range (<= %.1f °C).",
                        tempC, maxTemp)
        );
    }
}
