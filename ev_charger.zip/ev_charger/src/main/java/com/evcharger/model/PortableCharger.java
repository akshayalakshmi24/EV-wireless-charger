package com.evcharger.model;

/**
 * Domain model representing the simulated Portable Wireless EV Charger pad and power electronics.
 */
public class PortableCharger {

    private String chargerUnitId;
    private double nominalPowerKw;
    private double simulatedTemperatureC;
    private AlignmentStatus alignmentStatus;
    private EnergySource energySource;
    private ChargingStatus currentStatus;

    public PortableCharger(double nominalPowerKw,
                           double simulatedTemperatureC,
                           AlignmentStatus alignmentStatus,
                           EnergySource energySource) {
        this("PWC-UNIT-01", nominalPowerKw, simulatedTemperatureC, alignmentStatus, energySource);
    }

    public PortableCharger(String chargerUnitId,
                           double nominalPowerKw,
                           double simulatedTemperatureC,
                           AlignmentStatus alignmentStatus,
                           EnergySource energySource) {
        this.chargerUnitId = chargerUnitId;
        this.nominalPowerKw = nominalPowerKw;
        this.simulatedTemperatureC = simulatedTemperatureC;
        this.alignmentStatus = alignmentStatus;
        this.energySource = energySource;
        this.currentStatus = ChargingStatus.READY;
    }

    public String getChargerUnitId() {
        return chargerUnitId;
    }

    public void setChargerUnitId(String chargerUnitId) {
        this.chargerUnitId = chargerUnitId;
    }

    public double getNominalPowerKw() {
        return nominalPowerKw;
    }

    public void setNominalPowerKw(double nominalPowerKw) {
        this.nominalPowerKw = nominalPowerKw;
    }

    public double getSimulatedTemperatureC() {
        return simulatedTemperatureC;
    }

    public void setSimulatedTemperatureC(double simulatedTemperatureC) {
        this.simulatedTemperatureC = simulatedTemperatureC;
    }

    public AlignmentStatus getAlignmentStatus() {
        return alignmentStatus;
    }

    public void setAlignmentStatus(AlignmentStatus alignmentStatus) {
        this.alignmentStatus = alignmentStatus;
    }

    public EnergySource getEnergySource() {
        return energySource;
    }

    public void setEnergySource(EnergySource energySource) {
        this.energySource = energySource;
    }

    public ChargingStatus getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(ChargingStatus currentStatus) {
        this.currentStatus = currentStatus;
    }
}
