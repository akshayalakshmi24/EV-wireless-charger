package com.evcharger.model;

/**
 * Encapsulates the evaluation result of a pre-charging condition monitor
 * (BatteryMonitor, AlignmentMonitor, or TemperatureMonitor).
 */
public class MonitorCheckResult {

    private final String monitorName;
    private final boolean passed;
    private final boolean warning;
    private final String message;
    private final ChargingStatus resultingStatusIfFailed;

    public MonitorCheckResult(String monitorName,
                              boolean passed,
                              boolean warning,
                              String message,
                              ChargingStatus resultingStatusIfFailed) {
        this.monitorName = monitorName;
        this.passed = passed;
        this.warning = warning;
        this.message = message;
        this.resultingStatusIfFailed = resultingStatusIfFailed;
    }

    public static MonitorCheckResult pass(String monitorName, String message) {
        return new MonitorCheckResult(monitorName, true, false, message, ChargingStatus.READY);
    }

    public static MonitorCheckResult warn(String monitorName, String message) {
        return new MonitorCheckResult(monitorName, true, true, message, ChargingStatus.READY);
    }

    public static MonitorCheckResult block(String monitorName, String message, ChargingStatus blockStatus) {
        return new MonitorCheckResult(monitorName, false, false, message, blockStatus);
    }

    public String getMonitorName() {
        return monitorName;
    }

    public boolean isPassed() {
        return passed;
    }

    public boolean isWarning() {
        return warning;
    }

    public String getMessage() {
        return message;
    }

    public ChargingStatus getResultingStatusIfFailed() {
        return resultingStatusIfFailed;
    }
}
