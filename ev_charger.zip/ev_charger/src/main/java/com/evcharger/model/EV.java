package com.evcharger.model;

import java.util.Objects;

/**
 * Domain model representing a simulated Electric Vehicle (2-Wheeler or 3-Wheeler)
 * positioned over the portable wireless charging pad.
 *
 * <p>Demonstrates OOP encapsulation, constructor overloading, and domain behavior.</p>
 */
public class EV {

    private String evId;
    private VehicleType vehicleType;
    private int startBatteryPct;
    private int targetBatteryPct;
    private double batteryCapacityKwh;

    public EV(String evId, VehicleType vehicleType, int startBatteryPct, int targetBatteryPct) {
        this(evId, vehicleType, startBatteryPct, targetBatteryPct,
                vehicleType != null ? vehicleType.getDefaultCapacityKwh() : 3.2);
    }

    public EV(String evId, VehicleType vehicleType, int startBatteryPct, int targetBatteryPct, double batteryCapacityKwh) {
        this.evId = evId != null ? evId.trim().toUpperCase() : "";
        this.vehicleType = Objects.requireNonNull(vehicleType, "Vehicle type is required");
        this.startBatteryPct = startBatteryPct;
        this.targetBatteryPct = targetBatteryPct;
        this.batteryCapacityKwh = batteryCapacityKwh;
    }

    /**
     * Calculates the requested state-of-charge delta (%).
     */
    public int getRequestedBatteryDeltaPct() {
        return Math.max(0, targetBatteryPct - startBatteryPct);
    }

    /**
     * Calculates the net electrical energy (kWh) that must be delivered into the battery pack
     * to reach the target percentage from the starting percentage.
     */
    public double calculateNetEnergyNeededKwh() {
        int deltaPct = getRequestedBatteryDeltaPct();
        return (deltaPct / 100.0) * batteryCapacityKwh;
    }

    public String getEvId() {
        return evId;
    }

    public void setEvId(String evId) {
        this.evId = evId != null ? evId.trim().toUpperCase() : "";
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getStartBatteryPct() {
        return startBatteryPct;
    }

    public void setStartBatteryPct(int startBatteryPct) {
        this.startBatteryPct = startBatteryPct;
    }

    public int getTargetBatteryPct() {
        return targetBatteryPct;
    }

    public void setTargetBatteryPct(int targetBatteryPct) {
        this.targetBatteryPct = targetBatteryPct;
    }

    public double getBatteryCapacityKwh() {
        return batteryCapacityKwh;
    }

    public void setBatteryCapacityKwh(double batteryCapacityKwh) {
        this.batteryCapacityKwh = batteryCapacityKwh;
    }
}
