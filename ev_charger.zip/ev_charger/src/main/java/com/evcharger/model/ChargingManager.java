package com.evcharger.model;

import com.evcharger.config.SimulationProperties;
import com.evcharger.dto.ChargingCalculationResult;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Coordinates the simulated Auto-Trigger Wireless EV Charging workflow.
 *
 * <p>Demonstrates object-oriented composition, polymorphism via {@link ConditionMonitor},
 * collections ({@link ArrayList} and {@link HashMap}), state transitions, and clearly
 * documented mathematical simulation formulas.</p>
 */
@Component
public class ChargingManager {

    private final SimulationProperties simulationProperties;
    private final List<ConditionMonitor> conditionMonitors;

    public ChargingManager(SimulationProperties simulationProperties,
                           AlignmentMonitor alignmentMonitor,
                           TemperatureMonitor temperatureMonitor,
                           BatteryMonitor batteryMonitor) {
        this.simulationProperties = simulationProperties;
        this.conditionMonitors = new ArrayList<>();
        // Register pre-charge condition monitors in execution priority order
        this.conditionMonitors.add(alignmentMonitor);
        this.conditionMonitors.add(temperatureMonitor);
        this.conditionMonitors.add(batteryMonitor);
    }

    /**
     * Returns a lookup map of configured nominal battery capacities (kWh) per VehicleType.
     */
    public Map<VehicleType, Double> getConfiguredCapacityMap() {
        Map<VehicleType, Double> capacityMap = new HashMap<>();
        capacityMap.put(VehicleType.TWO_WHEELER, simulationProperties.getTwoWheelerCapacityKwh());
        capacityMap.put(VehicleType.THREE_WHEELER, simulationProperties.getThreeWheelerCapacityKwh());
        return capacityMap;
    }

    /**
     * Resolves the nominal battery capacity (kWh) for the given vehicle type.
     */
    public double resolveBatteryCapacityKwh(VehicleType vehicleType) {
        Map<VehicleType, Double> capacityMap = getConfiguredCapacityMap();
        return capacityMap.getOrDefault(vehicleType, vehicleType.getDefaultCapacityKwh());
    }

    /**
     * Executes the complete auto-trigger detection, validation, and simulated charging sequence.
     *
     * @param ev      the simulated Electric Vehicle
     * @param charger the simulated Portable Wireless Charger
     * @return a {@link ChargingCalculationResult} containing final status, energy metrics, and logs
     */
    public ChargingCalculationResult processAutoTriggerSession(EV ev, PortableCharger charger) {
        List<String> workflowLogs = new ArrayList<>();
        boolean thermalWarningDetected = false;

        // Step 1: Simulate EV proximity/inductive presence detection
        charger.setCurrentStatus(ChargingStatus.READY);
        workflowLogs.add(String.format(Locale.US,
                "EV detected: Vehicle %s (%s, %.1f kWh pack) positioned over wireless charging pad.",
                ev.getEvId(), ev.getVehicleType().getDisplayName(), ev.getBatteryCapacityKwh()));

        // Step 2: Polymorphically evaluate all registered ConditionMonitor instances
        for (ConditionMonitor monitor : conditionMonitors) {
            MonitorCheckResult checkResult = monitor.evaluate(ev, charger);
            workflowLogs.add(checkResult.getMessage());

            if (checkResult.isWarning()) {
                thermalWarningDetected = true;
            }

            if (!checkResult.isPassed()) {
                ChargingStatus blockedStatus = checkResult.getResultingStatusIfFailed();
                charger.setCurrentStatus(blockedStatus);

                return new ChargingCalculationResult(
                        blockedStatus,
                        ev.getStartBatteryPct(),
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        thermalWarningDetected,
                        checkResult.getMessage(),
                        workflowLogs
                );
            }
        }

        // Step 3: All safety & battery checks passed -> Auto-Trigger Charging
        charger.setCurrentStatus(ChargingStatus.CHARGING);
        workflowLogs.add(String.format(Locale.US,
                "Charging started: Automatic wireless power transfer initiated via %s power source.",
                charger.getEnergySource().getDisplayName()));

        // Step 4: Calculate wireless transfer efficiency (%)
        double efficiencyPct = calculateSimulatedEfficiencyPct(
                charger.getSimulatedTemperatureC(),
                charger.getAlignmentStatus(),
                charger.getEnergySource()
        );

        // Step 5: Calculate net energy delivered to EV battery (kWh) and gross energy drawn from source (kWh)
        double netEnergyDeliveredKwh = roundToThreeDecimals(ev.calculateNetEnergyNeededKwh());
        double grossEnergyConsumedKwh = roundToThreeDecimals(netEnergyDeliveredKwh / (efficiencyPct / 100.0));

        // Step 6: Calculate illustrative charging duration (minutes)
        double chargingTimeMin = calculateSimulatedChargingDurationMin(
                netEnergyDeliveredKwh,
                charger.getNominalPowerKw(),
                ev.getTargetBatteryPct(),
                thermalWarningDetected
        );

        // Step 7: Mark session COMPLETED
        charger.setCurrentStatus(ChargingStatus.COMPLETED);
        String completionMessage = String.format(Locale.US,
                "Charging completed: EV %s charged from %d%% to %d%% in %.1f min (%.3f kWh drawn at %.1f%% efficiency).",
                ev.getEvId(),
                ev.getStartBatteryPct(),
                ev.getTargetBatteryPct(),
                chargingTimeMin,
                grossEnergyConsumedKwh,
                efficiencyPct);

        if (thermalWarningDetected) {
            completionMessage = "Temperature warning observed during session. " + completionMessage;
        }
        workflowLogs.add(completionMessage);

        return new ChargingCalculationResult(
                ChargingStatus.COMPLETED,
                ev.getTargetBatteryPct(),
                chargingTimeMin,
                netEnergyDeliveredKwh,
                grossEnergyConsumedKwh,
                efficiencyPct,
                thermalWarningDetected,
                completionMessage,
                workflowLogs
        );
    }

    /**
     * Calculates simulated wireless power transfer efficiency (%) based on ambient/pad temperature,
     * alignment status, and energy source conversion stage.
     */
    public double calculateSimulatedEfficiencyPct(double temperatureC,
                                                  AlignmentStatus alignmentStatus,
                                                  EnergySource energySource) {
        if (alignmentStatus != AlignmentStatus.GOOD) {
            return 0.0;
        }

        double efficiency = simulationProperties.getBaseWirelessEfficiencyPct();

        // Thermal derating above 25 C reference temperature (or slight cold penalty below 15 C)
        if (temperatureC > 25.0) {
            efficiency -= (temperatureC - 25.0) * simulationProperties.getThermalDeratingPctPerC();
        } else if (temperatureC < 15.0) {
            efficiency -= (15.0 - temperatureC) * 0.08;
        }

        // Source power conversion stage modifier
        if (energySource == EnergySource.SOLAR) {
            efficiency += simulationProperties.getSolarEfficiencyBonusPct();
        } else if (energySource == EnergySource.SOLAR_GRID) {
            efficiency += simulationProperties.getHybridEfficiencyBonusPct();
        }

        // Clamp efficiency to realistic inductive resonant wireless range [75.0%, 96.0%]
        double clamped = Math.max(75.0, Math.min(96.0, efficiency));
        return roundToTwoDecimals(clamped);
    }

    /**
     * Calculates simulated charging duration in minutes.
     * Accounts for thermal power throttling when temperature is in the warning zone
     * and Constant-Voltage (CV) taper when charging above 80% SoC.
     */
    public double calculateSimulatedChargingDurationMin(double netEnergyDeliveredKwh,
                                                        double nominalPowerKw,
                                                        int targetBatteryPct,
                                                        boolean thermalWarning) {
        if (netEnergyDeliveredKwh <= 0.0 || nominalPowerKw <= 0.0) {
            return 0.0;
        }

        double effectivePowerKw = nominalPowerKw;

        // Apply 12% thermal power derating if operating in elevated temperature warning zone
        if (thermalWarning) {
            effectivePowerKw *= 0.88;
        }

        // Apply 10% CC-CV taper factor when charging into the upper 80%-100% SoC region
        if (targetBatteryPct > 80) {
            effectivePowerKw *= 0.90;
        }

        double durationMinutes = (netEnergyDeliveredKwh / effectivePowerKw) * 60.0;
        return Math.max(0.5, roundToOneDecimal(durationMinutes));
    }

    private double roundToOneDecimal(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    private double roundToTwoDecimals(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private double roundToThreeDecimals(double value) {
        return Math.round(value * 1000.0) / 1000.0;
    }
}
