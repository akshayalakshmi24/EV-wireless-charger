package com.evcharger.model;

/**
 * Interface defining a contract for all pre-charging safety and operational monitors.
 *
 * <p>Demonstrates Java interface design and polymorphism: ChargingManager iterates
 * over a collection of ConditionMonitor implementations to verify whether automatic
 * wireless power transfer can be triggered.</p>
 */
public interface ConditionMonitor {

    /**
     * Returns the human-readable name of this subsystem monitor.
     */
    String getMonitorName();

    /**
     * Evaluates the simulated EV and PortableCharger conditions.
     *
     * @param ev      the detected Electric Vehicle
     * @param charger the Portable Wireless Charger state
     * @return a {@link MonitorCheckResult} indicating pass, warning, or block reason
     */
    MonitorCheckResult evaluate(EV ev, PortableCharger charger);
}
