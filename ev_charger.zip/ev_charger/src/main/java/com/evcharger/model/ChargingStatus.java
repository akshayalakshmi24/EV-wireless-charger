package com.evcharger.model;

/**
 * Enum representing the finite-state machine states of a charging session.
 */
public enum ChargingStatus {

    READY("Ready", "secondary"),
    CHARGING("Charging", "primary"),
    COMPLETED("Completed", "success"),
    BLOCKED_ALIGNMENT("Blocked (Alignment)", "warning"),
    BLOCKED_TEMPERATURE("Blocked (Temperature)", "danger"),
    FAULT("Fault / Invalid State", "danger");

    private final String displayName;
    private final String badgeColor;

    ChargingStatus(String displayName, String badgeColor) {
        this.displayName = displayName;
        this.badgeColor = badgeColor;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeColor() {
        return badgeColor;
    }

    public boolean isSuccessful() {
        return this == COMPLETED;
    }

    public boolean isBlockedOrFault() {
        return this == BLOCKED_ALIGNMENT || this == BLOCKED_TEMPERATURE || this == FAULT;
    }
}
