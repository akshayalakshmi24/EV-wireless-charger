package com.evcharger.model;

import org.springframework.stereotype.Component;

/**
 * Monitors simulated inductive coil alignment between the portable charger pad
 * and the EV receiver coil.
 */
@Component
public class AlignmentMonitor extends AbstractConditionMonitor {

    public AlignmentMonitor() {
        super("Coil Alignment Monitor");
    }

    @Override
    public MonitorCheckResult evaluate(EV ev, PortableCharger charger) {
        if (charger == null || charger.getAlignmentStatus() == null) {
            return block("Charging blocked due to missing alignment status.", ChargingStatus.FAULT);
        }

        if (charger.getAlignmentStatus() == AlignmentStatus.GOOD) {
            return pass("Alignment check passed: Inductive transmitter and EV receiver coils are properly aligned (Good).");
        } else {
            return block(
                    "Charging blocked due to poor alignment: Inductive coupling efficiency is unsafe for wireless power transfer.",
                    ChargingStatus.BLOCKED_ALIGNMENT
            );
        }
    }
}
