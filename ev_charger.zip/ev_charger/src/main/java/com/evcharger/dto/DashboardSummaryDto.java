package com.evcharger.dto;

import java.util.List;
import java.util.Map;

/**
 * Data Transfer Object containing all dynamically calculated Dashboard KPIs
 * and Chart.js datasets derived from database records.
 */
public class DashboardSummaryDto {

    private final long totalSessions;
    private final long successfulSessions;
    private final long blockedOrFailedSessions;
    private final double avgStartBatteryPct;
    private final double totalEnergyConsumedKwh;
    private final double totalEnergyDeliveredKwh;
    private final double avgChargingTimeMin;
    private final double avgEfficiencyPct;
    private final long syntheticDemoCount;

    // Breakdown maps for charts and status summaries
    private final Map<String, Long> statusBreakdown;
    private final Map<String, Long> sessionsByEvType;
    private final Map<String, Double> energyByEvType;
    private final Map<String, Long> alignmentBreakdown;

    // Recent session labels & series for Temperature vs Efficiency and Energy charts
    private final List<String> recentCompletedLabels;
    private final List<Double> recentCompletedEnergyKwh;
    private final List<Double> recentCompletedTemperaturesC;
    private final List<Double> recentCompletedEfficienciesPct;

    public DashboardSummaryDto(long totalSessions,
                               long successfulSessions,
                               long blockedOrFailedSessions,
                               double avgStartBatteryPct,
                               double totalEnergyConsumedKwh,
                               double totalEnergyDeliveredKwh,
                               double avgChargingTimeMin,
                               double avgEfficiencyPct,
                               long syntheticDemoCount,
                               Map<String, Long> statusBreakdown,
                               Map<String, Long> sessionsByEvType,
                               Map<String, Double> energyByEvType,
                               Map<String, Long> alignmentBreakdown,
                               List<String> recentCompletedLabels,
                               List<Double> recentCompletedEnergyKwh,
                               List<Double> recentCompletedTemperaturesC,
                               List<Double> recentCompletedEfficienciesPct) {
        this.totalSessions = totalSessions;
        this.successfulSessions = successfulSessions;
        this.blockedOrFailedSessions = blockedOrFailedSessions;
        this.avgStartBatteryPct = avgStartBatteryPct;
        this.totalEnergyConsumedKwh = totalEnergyConsumedKwh;
        this.totalEnergyDeliveredKwh = totalEnergyDeliveredKwh;
        this.avgChargingTimeMin = avgChargingTimeMin;
        this.avgEfficiencyPct = avgEfficiencyPct;
        this.syntheticDemoCount = syntheticDemoCount;
        this.statusBreakdown = statusBreakdown;
        this.sessionsByEvType = sessionsByEvType;
        this.energyByEvType = energyByEvType;
        this.alignmentBreakdown = alignmentBreakdown;
        this.recentCompletedLabels = recentCompletedLabels;
        this.recentCompletedEnergyKwh = recentCompletedEnergyKwh;
        this.recentCompletedTemperaturesC = recentCompletedTemperaturesC;
        this.recentCompletedEfficienciesPct = recentCompletedEfficienciesPct;
    }

    public long getTotalSessions() {
        return totalSessions;
    }

    public long getSuccessfulSessions() {
        return successfulSessions;
    }

    public long getBlockedOrFailedSessions() {
        return blockedOrFailedSessions;
    }

    public double getAvgStartBatteryPct() {
        return avgStartBatteryPct;
    }

    public double getTotalEnergyConsumedKwh() {
        return totalEnergyConsumedKwh;
    }

    public double getTotalEnergyDeliveredKwh() {
        return totalEnergyDeliveredKwh;
    }

    public double getAvgChargingTimeMin() {
        return avgChargingTimeMin;
    }

    public double getAvgEfficiencyPct() {
        return avgEfficiencyPct;
    }

    public long getSyntheticDemoCount() {
        return syntheticDemoCount;
    }

    public Map<String, Long> getStatusBreakdown() {
        return statusBreakdown;
    }

    public Map<String, Long> getSessionsByEvType() {
        return sessionsByEvType;
    }

    public Map<String, Double> getEnergyByEvType() {
        return energyByEvType;
    }

    public Map<String, Long> getAlignmentBreakdown() {
        return alignmentBreakdown;
    }

    public List<String> getRecentCompletedLabels() {
        return recentCompletedLabels;
    }

    public List<Double> getRecentCompletedEnergyKwh() {
        return recentCompletedEnergyKwh;
    }

    public List<Double> getRecentCompletedTemperaturesC() {
        return recentCompletedTemperaturesC;
    }

    public List<Double> getRecentCompletedEfficienciesPct() {
        return recentCompletedEfficienciesPct;
    }
}
