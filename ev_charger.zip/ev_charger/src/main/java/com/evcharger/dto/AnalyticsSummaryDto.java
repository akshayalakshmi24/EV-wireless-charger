package com.evcharger.dto;

import java.util.List;
import java.util.Map;

/**
 * Data Transfer Object containing comprehensive statistical summaries and
 * Chart.js datasets for the Analytics page.
 */
public class AnalyticsSummaryDto {

    private final long totalSessions;
    private final long completedSessions;
    private final Map<String, Long> statusCounts;
    private final Map<String, Double> energyByEvType;
    private final Map<String, Double> avgTimeByAlignment;
    private final List<Map<String, Double>> temperatureEfficiencyPoints;
    private final Map<String, Long> sessionsOverTime;
    private final Map<String, Double> energyBySource;
    private final Map<String, Long> sessionsBySource;
    private final List<DescriptiveStatsDto> descriptiveStats;

    public AnalyticsSummaryDto(long totalSessions,
                               long completedSessions,
                               Map<String, Long> statusCounts,
                               Map<String, Double> energyByEvType,
                               Map<String, Double> avgTimeByAlignment,
                               List<Map<String, Double>> temperatureEfficiencyPoints,
                               Map<String, Long> sessionsOverTime,
                               Map<String, Double> energyBySource,
                               Map<String, Long> sessionsBySource,
                               List<DescriptiveStatsDto> descriptiveStats) {
        this.totalSessions = totalSessions;
        this.completedSessions = completedSessions;
        this.statusCounts = statusCounts;
        this.energyByEvType = energyByEvType;
        this.avgTimeByAlignment = avgTimeByAlignment;
        this.temperatureEfficiencyPoints = temperatureEfficiencyPoints;
        this.sessionsOverTime = sessionsOverTime;
        this.energyBySource = energyBySource;
        this.sessionsBySource = sessionsBySource;
        this.descriptiveStats = descriptiveStats;
    }

    public long getTotalSessions() {
        return totalSessions;
    }

    public long getCompletedSessions() {
        return completedSessions;
    }

    public Map<String, Long> getStatusCounts() {
        return statusCounts;
    }

    public Map<String, Double> getEnergyByEvType() {
        return energyByEvType;
    }

    public Map<String, Double> getAvgTimeByAlignment() {
        return avgTimeByAlignment;
    }

    public List<Map<String, Double>> getTemperatureEfficiencyPoints() {
        return temperatureEfficiencyPoints;
    }

    public Map<String, Long> getSessionsOverTime() {
        return sessionsOverTime;
    }

    public Map<String, Double> getEnergyBySource() {
        return energyBySource;
    }

    public Map<String, Long> getSessionsBySource() {
        return sessionsBySource;
    }

    public List<DescriptiveStatsDto> getDescriptiveStats() {
        return descriptiveStats;
    }
}
