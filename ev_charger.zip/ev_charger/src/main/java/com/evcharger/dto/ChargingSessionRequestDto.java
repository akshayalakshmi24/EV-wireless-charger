package com.evcharger.dto;

import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.EnergySource;
import com.evcharger.model.VehicleType;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Form Data Transfer Object (DTO) for submitting a new simulated EV charging session.
 * Uses Jakarta Bean Validation to validate user inputs before simulation begins.
 */
public class ChargingSessionRequestDto {

    @NotBlank(message = "EV ID is required (e.g., EV-2W-101).")
    @Size(min = 3, max = 30, message = "EV ID must be between 3 and 30 characters.")
    @Pattern(regexp = "^[A-Za-z0-9\\-_]+$", message = "EV ID may only contain letters, digits, hyphens, and underscores.")
    private String evId = "EV-2W-104";

    @NotNull(message = "Please select a vehicle type (2-Wheeler or 3-Wheeler).")
    private VehicleType vehicleType = VehicleType.TWO_WHEELER;

    @NotNull(message = "Starting battery percentage is required.")
    @Min(value = 0, message = "Starting battery percentage must be between 0% and 99%.")
    @Max(value = 99, message = "Starting battery percentage must be between 0% and 99%.")
    private Integer startBatteryPct = 25;

    @NotNull(message = "Target battery percentage is required.")
    @Min(value = 1, message = "Target battery percentage must be between 1% and 100%.")
    @Max(value = 100, message = "Target battery percentage must be between 1% and 100%.")
    private Integer targetBatteryPct = 85;

    @NotNull(message = "Simulated temperature in Celsius is required.")
    @DecimalMin(value = "-20.0", message = "Simulated temperature cannot be below -20.0 °C.")
    @DecimalMax(value = "85.0", message = "Simulated temperature cannot exceed 85.0 °C.")
    private Double temperatureC = 31.5;

    @NotNull(message = "Please select the simulated coil alignment status.")
    private AlignmentStatus alignmentStatus = AlignmentStatus.GOOD;

    @NotNull(message = "Please select an energy source.")
    private EnergySource energySource = EnergySource.SOLAR_GRID;

    public ChargingSessionRequestDto() {
    }

    public ChargingSessionRequestDto(String evId,
                                     VehicleType vehicleType,
                                     Integer startBatteryPct,
                                     Integer targetBatteryPct,
                                     Double temperatureC,
                                     AlignmentStatus alignmentStatus,
                                     EnergySource energySource) {
        this.evId = evId;
        this.vehicleType = vehicleType;
        this.startBatteryPct = startBatteryPct;
        this.targetBatteryPct = targetBatteryPct;
        this.temperatureC = temperatureC;
        this.alignmentStatus = alignmentStatus;
        this.energySource = energySource;
    }

    public String getEvId() {
        return evId;
    }

    public void setEvId(String evId) {
        this.evId = evId;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public Integer getStartBatteryPct() {
        return startBatteryPct;
    }

    public void setStartBatteryPct(Integer startBatteryPct) {
        this.startBatteryPct = startBatteryPct;
    }

    public Integer getTargetBatteryPct() {
        return targetBatteryPct;
    }

    public void setTargetBatteryPct(Integer targetBatteryPct) {
        this.targetBatteryPct = targetBatteryPct;
    }

    public Double getTemperatureC() {
        return temperatureC;
    }

    public void setTemperatureC(Double temperatureC) {
        this.temperatureC = temperatureC;
    }

    public AlignmentStatus getAlignmentStatus() {
        return alignmentStatus;
    }

    public void setAlignmentStatus(AlignmentStatus alignmentStatus) {
        this.alignmentStatus = alignmentStatus;
    }

    public EnergySource getEnergySource() {
        return energySource;
    }

    public void setEnergySource(EnergySource energySource) {
        this.energySource = energySource;
    }
}
