package com.evcharger.dto;

import com.evcharger.model.ChargingStatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Encapsulates the outcome of the ChargingManager simulation workflow,
 * distinguishing between net energy delivered to the EV battery and total
 * energy drawn (consumed) from the power source.
 */
public class ChargingCalculationResult {

    private final ChargingStatus finalStatus;
    private final int endBatteryPct;
    private final double chargingTimeMin;
    private final double energyDeliveredKwh;
    private final double energyConsumedKwh;
    private final double chargingEfficiencyPct;
    private final boolean temperatureWarning;
    private final String primaryStatusMessage;
    private final List<String> workflowLogs;

    public ChargingCalculationResult(ChargingStatus finalStatus,
                                     int endBatteryPct,
                                     double chargingTimeMin,
                                     double energyDeliveredKwh,
                                     double energyConsumedKwh,
                                     double chargingEfficiencyPct,
                                     boolean temperatureWarning,
                                     String primaryStatusMessage,
                                     List<String> workflowLogs) {
        this.finalStatus = finalStatus;
        this.endBatteryPct = endBatteryPct;
        this.chargingTimeMin = Math.max(0.0, chargingTimeMin);
        this.energyDeliveredKwh = Math.max(0.0, energyDeliveredKwh);
        this.energyConsumedKwh = Math.max(0.0, energyConsumedKwh);
        this.chargingEfficiencyPct = Math.max(0.0, chargingEfficiencyPct);
        this.temperatureWarning = temperatureWarning;
        this.primaryStatusMessage = primaryStatusMessage;
        this.workflowLogs = workflowLogs != null
                ? new ArrayList<>(workflowLogs)
                : new ArrayList<>();
    }

    public ChargingStatus getFinalStatus() {
        return finalStatus;
    }

    public int getEndBatteryPct() {
        return endBatteryPct;
    }

    public double getChargingTimeMin() {
        return chargingTimeMin;
    }

    public double getEnergyDeliveredKwh() {
        return energyDeliveredKwh;
    }

    public double getEnergyConsumedKwh() {
        return energyConsumedKwh;
    }

    public double getChargingEfficiencyPct() {
        return chargingEfficiencyPct;
    }

    public boolean isTemperatureWarning() {
        return temperatureWarning;
    }

    public String getPrimaryStatusMessage() {
        return primaryStatusMessage;
    }

    public List<String> getWorkflowLogs() {
        return Collections.unmodifiableList(workflowLogs);
    }
}
