package com.evcharger.dto;

/**
 * Holds descriptive statistical metrics (Count, Mean, Minimum, Maximum, Standard Deviation)
 * for a numerical simulation variable on the Analytics page.
 */
public class DescriptiveStatsDto {

    private final String metricName;
    private final String unit;
    private final int count;
    private final double mean;
    private final double min;
    private final double max;
    private final double stdDev;

    public DescriptiveStatsDto(String metricName,
                               String unit,
                               int count,
                               double mean,
                               double min,
                               double max,
                               double stdDev) {
        this.metricName = metricName;
        this.unit = unit;
        this.count = count;
        this.mean = mean;
        this.min = min;
        this.max = max;
        this.stdDev = stdDev;
    }

    public String getMetricName() {
        return metricName;
    }

    public String getUnit() {
        return unit;
    }

    public int getCount() {
        return count;
    }

    public double getMean() {
        return mean;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStdDev() {
        return stdDev;
    }
}
