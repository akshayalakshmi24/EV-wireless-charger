package com.evcharger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Main entry point for the Auto-Trigger Portable Wireless EV Charger
 * Java-Based Charging Management System.
 *
 * <p>NOTE: This software is an educational simulation and management system
 * designed for Data Thinking, Data Exploration & Visualization, and Java Programming.
 * It simulates vehicle detection, coil alignment verification, thermal monitoring,
 * and wireless power transfer calculations without controlling physical hardware.</p>
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class EvChargerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EvChargerApplication.class, args);
    }
}
