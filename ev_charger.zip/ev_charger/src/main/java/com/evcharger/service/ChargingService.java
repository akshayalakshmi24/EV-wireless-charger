package com.evcharger.service;

import com.evcharger.config.SimulationProperties;
import com.evcharger.dto.ChargingCalculationResult;
import com.evcharger.dto.ChargingSessionRequestDto;
import com.evcharger.entity.ChargingSession;
import com.evcharger.exception.InvalidChargingParameterException;
import com.evcharger.model.ChargingManager;
import com.evcharger.model.EV;
import com.evcharger.model.PortableCharger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Application service that coordinates EV detection, pre-charging safety checks,
 * charging simulation calculations, and database persistence.
 */
@Service
public class ChargingService {

    private final ChargingManager chargingManager;
    private final SessionDataService sessionDataService;
    private final SimulationProperties simulationProperties;

    public ChargingService(ChargingManager chargingManager,
                           SessionDataService sessionDataService,
                           SimulationProperties simulationProperties) {
        this.chargingManager = chargingManager;
        this.sessionDataService = sessionDataService;
        this.simulationProperties = simulationProperties;
    }

    /**
     * Value object pairing the persisted {@link ChargingSession} entity with the
     * step-by-step {@link ChargingCalculationResult} workflow logs.
     */
    public static class SessionExecutionOutcome {
        private final ChargingSession session;
        private final ChargingCalculationResult calculationResult;

        public SessionExecutionOutcome(ChargingSession session, ChargingCalculationResult calculationResult) {
            this.session = session;
            this.calculationResult = calculationResult;
        }

        public ChargingSession getSession() {
            return session;
        }

        public ChargingCalculationResult getCalculationResult() {
            return calculationResult;
        }
    }

    /**
     * Processes a user-submitted charging request, runs all simulated monitors,
     * persists the resulting session (whether COMPLETED or BLOCKED/FAULT), and
     * returns the full outcome.
     */
    @Transactional
    public SessionExecutionOutcome detectAndTriggerCharging(ChargingSessionRequestDto request) {
        validateNotNullFields(request);

        double capacityKwh = chargingManager.resolveBatteryCapacityKwh(request.getVehicleType());

        EV ev = new EV(
                request.getEvId().trim().toUpperCase(),
                request.getVehicleType(),
                request.getStartBatteryPct(),
                request.getTargetBatteryPct(),
                capacityKwh
        );

        PortableCharger charger = new PortableCharger(
                simulationProperties.getNominalChargerPowerKw(),
                request.getTemperatureC(),
                request.getAlignmentStatus(),
                request.getEnergySource()
        );

        ChargingCalculationResult calcResult = chargingManager.processAutoTriggerSession(ev, charger);

        ChargingSession entity = new ChargingSession(
                ev.getEvId(),
                ev.getVehicleType(),
                ev.getStartBatteryPct(),
                ev.getTargetBatteryPct(),
                calcResult.getEndBatteryPct(),
                request.getTemperatureC(),
                request.getAlignmentStatus(),
                calcResult.getChargingTimeMin(),
                calcResult.getEnergyDeliveredKwh(),
                calcResult.getEnergyConsumedKwh(),
                calcResult.getChargingEfficiencyPct(),
                request.getEnergySource(),
                calcResult.getFinalStatus(),
                calcResult.getPrimaryStatusMessage(),
                false,
                LocalDateTime.now()
        );

        ChargingSession savedSession = sessionDataService.saveSession(entity);
        return new SessionExecutionOutcome(savedSession, calcResult);
    }

    private void validateNotNullFields(ChargingSessionRequestDto request) {
        if (request == null) {
            throw new InvalidChargingParameterException("Charging session request cannot be null.");
        }
        if (request.getEvId() == null || request.getEvId().isBlank()) {
            throw new InvalidChargingParameterException("EV ID is required.");
        }
        if (request.getVehicleType() == null) {
            throw new InvalidChargingParameterException("Vehicle type is required.");
        }
        if (request.getStartBatteryPct() == null || request.getTargetBatteryPct() == null) {
            throw new InvalidChargingParameterException("Starting and target battery percentages are required.");
        }
        if (request.getTemperatureC() == null) {
            throw new InvalidChargingParameterException("Simulated temperature is required.");
        }
        if (request.getAlignmentStatus() == null) {
            throw new InvalidChargingParameterException("Coil alignment status is required.");
        }
        if (request.getEnergySource() == null) {
            throw new InvalidChargingParameterException("Energy source is required.");
        }
    }
}
