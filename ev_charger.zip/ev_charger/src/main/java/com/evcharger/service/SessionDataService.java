package com.evcharger.service;

import com.evcharger.config.SimulationProperties;
import com.evcharger.dto.ChargingCalculationResult;
import com.evcharger.entity.ChargingSession;
import com.evcharger.exception.SessionNotFoundException;
import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingManager;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.EV;
import com.evcharger.model.EnergySource;
import com.evcharger.model.PortableCharger;
import com.evcharger.model.VehicleType;
import com.evcharger.repository.ChargingSessionRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Service responsible for persisting, querying, filtering, and seeding
 * {@link ChargingSession} records in the H2 database.
 */
@Service
public class SessionDataService {

    private final ChargingSessionRepository sessionRepository;
    private final ChargingManager chargingManager;
    private final SimulationProperties simulationProperties;

    public SessionDataService(ChargingSessionRepository sessionRepository,
                              ChargingManager chargingManager,
                              SimulationProperties simulationProperties) {
        this.sessionRepository = sessionRepository;
        this.chargingManager = chargingManager;
        this.simulationProperties = simulationProperties;
    }

    /**
     * Automatically seeds a small starter set of 12 realistic demonstration sessions
     * on first startup if the database is completely empty and startup seeding is enabled.
     */
    @PostConstruct
    @Transactional
    public void initializeStarterDataIfEmpty() {
        if (simulationProperties.isSeedInitialDataOnStartup() && sessionRepository.count() == 0) {
            generateReproducibleDemoSessions(12, false);
        }
    }

    /**
     * Persists a single ChargingSession record (completed or blocked).
     */
    @Transactional
    public ChargingSession saveSession(ChargingSession session) {
        return sessionRepository.save(session);
    }

    /**
     * Retrieves all stored charging sessions ordered newest first.
     */
    @Transactional(readOnly = true)
    public List<ChargingSession> getAllSessionsNewestFirst() {
        return sessionRepository.findAllByOrderBySessionTimestampDesc();
    }

    /**
     * Retrieves all stored charging sessions ordered by sessionId ascending (for CSV export).
     */
    @Transactional(readOnly = true)
    public List<ChargingSession> getAllSessionsChronological() {
        return sessionRepository.findAllByOrderBySessionIdAsc();
    }

    /**
     * Retrieves the 8 most recent sessions for the Dashboard table.
     */
    @Transactional(readOnly = true)
    public List<ChargingSession> getRecentSessionsForDashboard() {
        return sessionRepository.findTop8ByOrderBySessionTimestampDesc();
    }

    /**
     * Finds a single session by ID or throws {@link SessionNotFoundException}.
     */
    @Transactional(readOnly = true)
    public ChargingSession getSessionById(Long sessionId) {
        return sessionRepository.findById(sessionId)
                .orElseThrow(() -> new SessionNotFoundException(sessionId));
    }

    /**
     * Counts how many synthetic demo sessions are currently stored.
     */
    @Transactional(readOnly = true)
    public long countSyntheticDemoSessions() {
        return sessionRepository.countBySyntheticDemoTrue();
    }

    /**
     * Searches, filters, and sorts charging sessions for the Charging History page.
     */
    @Transactional(readOnly = true)
    public List<ChargingSession> searchAndSortSessions(String searchQuery,
                                                       String vehicleTypeFilter,
                                                       String statusFilter,
                                                       String alignmentFilter,
                                                       String sortBy,
                                                       String sortDir) {
        List<ChargingSession> allSessions = sessionRepository.findAllByOrderBySessionTimestampDesc();
        List<ChargingSession> filtered = new ArrayList<>();

        String normalizedQuery = searchQuery != null ? searchQuery.trim().toLowerCase(Locale.ROOT) : "";

        for (ChargingSession session : allSessions) {
            // Search by EV ID, Session ID, or Energy Source
            if (!normalizedQuery.isEmpty()) {
                boolean matchesEvId = session.getEvId().toLowerCase(Locale.ROOT).contains(normalizedQuery);
                boolean matchesId = String.valueOf(session.getSessionId()).contains(normalizedQuery);
                boolean matchesSource = session.getEnergySource().getDisplayName().toLowerCase(Locale.ROOT).contains(normalizedQuery);
                if (!matchesEvId && !matchesId && !matchesSource) {
                    continue;
                }
            }

            // Filter by VehicleType
            if (vehicleTypeFilter != null && !vehicleTypeFilter.isBlank() && !"ALL".equalsIgnoreCase(vehicleTypeFilter)) {
                if (!session.getVehicleType().name().equalsIgnoreCase(vehicleTypeFilter)
                        && !session.getVehicleType().getDisplayName().equalsIgnoreCase(vehicleTypeFilter)) {
                    continue;
                }
            }

            // Filter by ChargingStatus
            if (statusFilter != null && !statusFilter.isBlank() && !"ALL".equalsIgnoreCase(statusFilter)) {
                if (!session.getStatus().name().equalsIgnoreCase(statusFilter)) {
                    continue;
                }
            }

            // Filter by AlignmentStatus
            if (alignmentFilter != null && !alignmentFilter.isBlank() && !"ALL".equalsIgnoreCase(alignmentFilter)) {
                if (!session.getAlignmentStatus().name().equalsIgnoreCase(alignmentFilter)
                        && !session.getAlignmentStatus().getDisplayName().equalsIgnoreCase(alignmentFilter)) {
                    continue;
                }
            }

            filtered.add(session);
        }

        // Apply sorting
        Comparator<ChargingSession> comparator = buildComparator(sortBy);
        if ("asc".equalsIgnoreCase(sortDir)) {
            filtered.sort(comparator);
        } else {
            filtered.sort(comparator.reversed());
        }

        return filtered;
    }

    private Comparator<ChargingSession> buildComparator(String sortBy) {
        if (sortBy == null) {
            return Comparator.comparing(ChargingSession::getSessionTimestamp);
        }
        return switch (sortBy.toLowerCase(Locale.ROOT)) {
            case "sessionid" -> Comparator.comparing(ChargingSession::getSessionId);
            case "evid" -> Comparator.comparing(ChargingSession::getEvId);
            case "temperature" -> Comparator.comparingDouble(ChargingSession::getTemperatureC);
            case "duration" -> Comparator.comparingDouble(ChargingSession::getChargingTimeMin);
            case "energy" -> Comparator.comparingDouble(ChargingSession::getEnergyConsumedKwh);
            case "efficiency" -> Comparator.comparingDouble(ChargingSession::getChargingEfficiencyPct);
            case "startbattery" -> Comparator.comparingInt(ChargingSession::getStartBatteryPct);
            default -> Comparator.comparing(ChargingSession::getSessionTimestamp);
        };
    }

    /**
     * Generates 100 reproducible synthetic demo charging sessions using a fixed random seed.
     *
     * <p>To prevent accidental duplicate generation when the user clicks the button
     * repeatedly, if {@code replaceExistingDemoBatch} is true (or if 100+ demo records already
     * exist), existing synthetic demo records are replaced cleanly while preserving any
     * manually created user sessions.</p>
     *
     * @param count                    number of synthetic sessions to generate (typically 100)
     * @param replaceExistingDemoBatch whether to clear existing synthetic demo records first
     * @return number of newly generated synthetic sessions
     */
    @Transactional
    public int generateReproducibleDemoSessions(int count, boolean replaceExistingDemoBatch) {
        if (replaceExistingDemoBatch) {
            sessionRepository.deleteBySyntheticDemoTrue();
            sessionRepository.flush();
        }

        Random random = new Random(simulationProperties.getDemoRandomSeed());
        List<ChargingSession> batch = new ArrayList<>(count);
        LocalDateTime baseTime = LocalDateTime.now().minusDays(14).withHour(8).withMinute(0).withSecond(0).withNano(0);

        for (int i = 1; i <= count; i++) {
            // 62% 2-Wheelers, 38% 3-Wheelers
            VehicleType vehicleType = (random.nextDouble() < 0.62)
                    ? VehicleType.TWO_WHEELER
                    : VehicleType.THREE_WHEELER;

            String prefix = (vehicleType == VehicleType.TWO_WHEELER) ? "SYN-2W-" : "SYN-3W-";
            String evId = String.format(Locale.US, "%s%03d", prefix, 100 + (i % 45));

            // Realistic starting battery: 10% to 65%
            int startBattery = 10 + random.nextInt(56);
            // Realistic target battery: 75% to 100% (ensuring target > start)
            int targetBattery = Math.min(100, Math.max(startBattery + 15, 75 + random.nextInt(26)));

            // Energy source distribution: 35% Solar, 35% Grid, 30% Solar + Grid
            double sourceRoll = random.nextDouble();
            EnergySource energySource;
            if (sourceRoll < 0.35) {
                energySource = EnergySource.SOLAR;
            } else if (sourceRoll < 0.70) {
                energySource = EnergySource.GRID;
            } else {
                energySource = EnergySource.SOLAR_GRID;
            }

            // Scenario distribution:
            // ~76% Good alignment & safe temperature (COMPLETED)
            // ~14% Poor coil alignment (BLOCKED_ALIGNMENT)
            // ~10% Excessive temperature > 45 C (BLOCKED_TEMPERATURE)
            double scenarioRoll = random.nextDouble();
            AlignmentStatus alignmentStatus;
            double temperatureC;

            if (scenarioRoll < 0.76) {
                alignmentStatus = AlignmentStatus.GOOD;
                // Safe temperature between 22.0 C and 43.8 C (includes some thermal warning cases >= 40 C)
                temperatureC = roundOneDecimal(22.0 + random.nextDouble() * 21.8);
            } else if (scenarioRoll < 0.90) {
                alignmentStatus = AlignmentStatus.POOR;
                temperatureC = roundOneDecimal(24.0 + random.nextDouble() * 16.0);
            } else {
                alignmentStatus = AlignmentStatus.GOOD;
                // Unsafe temperature between 45.4 C and 54.5 C -> triggers BLOCKED_TEMPERATURE
                temperatureC = roundOneDecimal(45.4 + random.nextDouble() * 9.1);
            }

            double capacityKwh = chargingManager.resolveBatteryCapacityKwh(vehicleType);
            EV ev = new EV(evId, vehicleType, startBattery, targetBattery, capacityKwh);
            PortableCharger charger = new PortableCharger(
                    simulationProperties.getNominalChargerPowerKw(),
                    temperatureC,
                    alignmentStatus,
                    energySource
            );

            // Run through the exact same ChargingManager rules to guarantee zero contradictions
            ChargingCalculationResult calc = chargingManager.processAutoTriggerSession(ev, charger);

            // Advance timestamp chronologically by 2 to 4 hours per record
            baseTime = baseTime.plusMinutes(95 + random.nextInt(140));

            ChargingSession session = new ChargingSession(
                    ev.getEvId(),
                    ev.getVehicleType(),
                    ev.getStartBatteryPct(),
                    ev.getTargetBatteryPct(),
                    calc.getEndBatteryPct(),
                    temperatureC,
                    alignmentStatus,
                    calc.getChargingTimeMin(),
                    calc.getEnergyDeliveredKwh(),
                    calc.getEnergyConsumedKwh(),
                    calc.getChargingEfficiencyPct(),
                    energySource,
                    calc.getFinalStatus(),
                    "[SYNTHETIC DEMO] " + calc.getPrimaryStatusMessage(),
                    true,
                    baseTime
            );

            batch.add(session);
        }

        sessionRepository.saveAll(batch);
        return batch.size();
    }

    private double roundOneDecimal(double val) {
        return Math.round(val * 10.0) / 10.0;
    }
}
