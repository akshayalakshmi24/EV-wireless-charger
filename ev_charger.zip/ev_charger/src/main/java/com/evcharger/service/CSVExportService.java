package com.evcharger.service;

import com.evcharger.entity.ChargingSession;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Service responsible for exporting stored {@link ChargingSession} records
 * to RFC-4180 compliant CSV format for Excel and Python (Pandas / NumPy / Seaborn) EDA.
 *
 * <p>Demonstrates Java file handling ({@link Files}, {@link BufferedWriter}),
 * string building, and proper CSV escaping.</p>
 */
@Service
public class CSVExportService {

    public static final String CSV_HEADER =
            "Session_ID,EV_ID,Vehicle_Type,Start_Battery_pct,Target_Battery_pct,End_Battery_pct," +
            "Temperature_C,Alignment_Status,Charging_Time_min,Energy_Consumed_kWh," +
            "Charging_Efficiency_pct,Energy_Source,Status,Session_Timestamp";

    private static final DateTimeFormatter CSV_TIMESTAMP_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final SessionDataService sessionDataService;

    public CSVExportService(SessionDataService sessionDataService) {
        this.sessionDataService = sessionDataService;
    }

    /**
     * Generates the complete CSV string for all stored charging sessions.
     */
    @Transactional(readOnly = true)
    public String exportAllSessionsToCsvString() {
        List<ChargingSession> sessions = sessionDataService.getAllSessionsChronological();
        return generateCsvContent(sessions);
    }

    /**
     * Converts a list of {@link ChargingSession} entities into a valid CSV string.
     */
    public String generateCsvContent(List<ChargingSession> sessions) {
        StringBuilder sb = new StringBuilder();
        sb.append(CSV_HEADER).append("\r\n");

        if (sessions == null || sessions.isEmpty()) {
            return sb.toString();
        }

        for (ChargingSession session : sessions) {
            sb.append(session.getSessionId() != null ? session.getSessionId() : "").append(",");
            sb.append(escapeCsvField(session.getEvId())).append(",");
            sb.append(escapeCsvField(session.getVehicleType() != null ? session.getVehicleType().getDisplayName() : "")).append(",");
            sb.append(session.getStartBatteryPct()).append(",");
            sb.append(session.getTargetBatteryPct()).append(",");
            sb.append(session.getEndBatteryPct()).append(",");
            sb.append(String.format(Locale.US, "%.1f", session.getTemperatureC())).append(",");
            sb.append(escapeCsvField(session.getAlignmentStatus() != null ? session.getAlignmentStatus().getDisplayName() : "")).append(",");
            sb.append(String.format(Locale.US, "%.1f", session.getChargingTimeMin())).append(",");
            sb.append(String.format(Locale.US, "%.3f", session.getEnergyConsumedKwh())).append(",");
            sb.append(String.format(Locale.US, "%.2f", session.getChargingEfficiencyPct())).append(",");
            sb.append(escapeCsvField(session.getEnergySource() != null ? session.getEnergySource().getDisplayName() : "")).append(",");
            sb.append(escapeCsvField(session.getStatus() != null ? session.getStatus().name() : "")).append(",");
            String formattedTime = session.getSessionTimestamp() != null
                    ? session.getSessionTimestamp().format(CSV_TIMESTAMP_FORMATTER)
                    : "";
            sb.append(escapeCsvField(formattedTime)).append("\r\n");
        }

        return sb.toString();
    }

    /**
     * Writes all stored charging sessions to a local CSV file on disk using Java NIO BufferedWriter.
     *
     * @param filePath destination file path
     * @return absolute path of the written CSV file
     * @throws IOException if file writing fails
     */
    @Transactional(readOnly = true)
    public Path writeSessionsToCsvFile(Path filePath) throws IOException {
        if (filePath.getParent() != null) {
            Files.createDirectories(filePath.getParent());
        }
        String csvContent = exportAllSessionsToCsvString();
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardCharsets.UTF_8)) {
            writer.write(csvContent);
        }
        return filePath.toAbsolutePath();
    }

    /**
     * Escapes a string field according to RFC 4180 CSV rules.
     */
    public String escapeCsvField(String value) {
        if (value == null) {
            return "";
        }
        boolean requiresQuotes = value.contains(",")
                || value.contains("\"")
                || value.contains("\n")
                || value.contains("\r");
        if (!requiresQuotes) {
            return value;
        }
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}
