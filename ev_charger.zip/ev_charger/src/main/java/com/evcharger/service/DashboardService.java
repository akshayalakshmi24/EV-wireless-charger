package com.evcharger.service;

import com.evcharger.dto.AnalyticsSummaryDto;
import com.evcharger.dto.DashboardSummaryDto;
import com.evcharger.dto.DescriptiveStatsDto;
import com.evcharger.entity.ChargingSession;
import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.EnergySource;
import com.evcharger.model.VehicleType;
import com.evcharger.repository.ChargingSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Service that calculates Dashboard KPI metrics, Chart.js datasets, and
 * Analytics descriptive statistics directly from H2 database records.
 *
 * <p>Demonstrates genuine use of Java collections ({@link ArrayList}, {@link HashMap},
 * {@link LinkedHashMap}, {@link TreeMap}), loops, conditional aggregation, and
 * statistical calculations (Mean, Min, Max, Standard Deviation).</p>
 */
@Service
public class DashboardService {

    private static final DateTimeFormatter DATE_BUCKET_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final ChargingSessionRepository sessionRepository;

    public DashboardService(ChargingSessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    /**
     * Calculates all Dashboard KPI metrics and chart series from stored database records.
     */
    @Transactional(readOnly = true)
    public DashboardSummaryDto buildDashboardSummary() {
        List<ChargingSession> allSessions = sessionRepository.findAllByOrderBySessionTimestampDesc();
        long syntheticDemoCount = sessionRepository.countBySyntheticDemoTrue();

        long totalSessions = allSessions.size();
        long successfulSessions = 0L;
        long blockedOrFailedSessions = 0L;

        double sumStartBattery = 0.0;
        double totalEnergyConsumed = 0.0;
        double totalEnergyDelivered = 0.0;
        double sumCompletedDuration = 0.0;
        double sumCompletedEfficiency = 0.0;

        Map<String, Long> statusBreakdown = new LinkedHashMap<>();
        statusBreakdown.put(ChargingStatus.COMPLETED.getDisplayName(), 0L);
        statusBreakdown.put(ChargingStatus.BLOCKED_ALIGNMENT.getDisplayName(), 0L);
        statusBreakdown.put(ChargingStatus.BLOCKED_TEMPERATURE.getDisplayName(), 0L);
        statusBreakdown.put(ChargingStatus.FAULT.getDisplayName(), 0L);

        Map<String, Long> sessionsByEvType = new LinkedHashMap<>();
        Map<String, Double> energyByEvType = new LinkedHashMap<>();
        for (VehicleType vt : VehicleType.values()) {
            sessionsByEvType.put(vt.getDisplayName(), 0L);
            energyByEvType.put(vt.getDisplayName(), 0.0);
        }

        Map<String, Long> alignmentBreakdown = new LinkedHashMap<>();
        for (AlignmentStatus align : AlignmentStatus.values()) {
            alignmentBreakdown.put(align.getDisplayName(), 0L);
        }

        List<ChargingSession> completedRecent = new ArrayList<>();

        for (ChargingSession session : allSessions) {
            sumStartBattery += session.getStartBatteryPct();
            totalEnergyConsumed += session.getEnergyConsumedKwh();
            totalEnergyDelivered += session.getEnergyDeliveredKwh();

            ChargingStatus status = session.getStatus();
            String statusLabel = status.getDisplayName();
            statusBreakdown.put(statusLabel, statusBreakdown.getOrDefault(statusLabel, 0L) + 1L);

            String evLabel = session.getVehicleType().getDisplayName();
            sessionsByEvType.put(evLabel, sessionsByEvType.getOrDefault(evLabel, 0L) + 1L);
            energyByEvType.put(evLabel, roundTwoDecimals(energyByEvType.getOrDefault(evLabel, 0.0) + session.getEnergyConsumedKwh()));

            String alignLabel = session.getAlignmentStatus().getDisplayName();
            alignmentBreakdown.put(alignLabel, alignmentBreakdown.getOrDefault(alignLabel, 0L) + 1L);

            if (status.isSuccessful()) {
                successfulSessions++;
                sumCompletedDuration += session.getChargingTimeMin();
                sumCompletedEfficiency += session.getChargingEfficiencyPct();
                if (completedRecent.size() < 12) {
                    completedRecent.add(session);
                }
            } else if (status.isBlockedOrFault()) {
                blockedOrFailedSessions++;
            }
        }

        // Reverse completedRecent so charts plot chronologically left-to-right
        Collections.reverse(completedRecent);
        List<String> recentLabels = new ArrayList<>();
        List<Double> recentEnergy = new ArrayList<>();
        List<Double> recentTemp = new ArrayList<>();
        List<Double> recentEfficiency = new ArrayList<>();

        for (ChargingSession cs : completedRecent) {
            recentLabels.add("#" + cs.getSessionId() + " (" + cs.getEvId() + ")");
            recentEnergy.add(roundThreeDecimals(cs.getEnergyConsumedKwh()));
            recentTemp.add(roundOneDecimal(cs.getTemperatureC()));
            recentEfficiency.add(roundTwoDecimals(cs.getChargingEfficiencyPct()));
        }

        double avgStartBattery = totalSessions > 0 ? roundOneDecimal(sumStartBattery / totalSessions) : 0.0;
        double avgChargingTime = successfulSessions > 0 ? roundOneDecimal(sumCompletedDuration / successfulSessions) : 0.0;
        double avgEfficiency = successfulSessions > 0 ? roundTwoDecimals(sumCompletedEfficiency / successfulSessions) : 0.0;

        return new DashboardSummaryDto(
                totalSessions,
                successfulSessions,
                blockedOrFailedSessions,
                avgStartBattery,
                roundThreeDecimals(totalEnergyConsumed),
                roundThreeDecimals(totalEnergyDelivered),
                avgChargingTime,
                avgEfficiency,
                syntheticDemoCount,
                statusBreakdown,
                sessionsByEvType,
                energyByEvType,
                alignmentBreakdown,
                recentLabels,
                recentEnergy,
                recentTemp,
                recentEfficiency
        );
    }

    /**
     * Calculates comprehensive Analytics chart datasets and descriptive statistics
     * (Mean, Min, Max, Standard Deviation) from all stored charging sessions.
     */
    @Transactional(readOnly = true)
    public AnalyticsSummaryDto buildAnalyticsSummary() {
        List<ChargingSession> allSessions = sessionRepository.findAllByOrderBySessionIdAsc();

        long totalSessions = allSessions.size();
        long completedSessions = 0L;

        Map<String, Long> statusCounts = new LinkedHashMap<>();
        statusCounts.put(ChargingStatus.COMPLETED.getDisplayName(), 0L);
        statusCounts.put(ChargingStatus.BLOCKED_ALIGNMENT.getDisplayName(), 0L);
        statusCounts.put(ChargingStatus.BLOCKED_TEMPERATURE.getDisplayName(), 0L);
        statusCounts.put(ChargingStatus.FAULT.getDisplayName(), 0L);

        Map<String, Double> energyByEvType = new LinkedHashMap<>();
        for (VehicleType vt : VehicleType.values()) {
            energyByEvType.put(vt.getDisplayName(), 0.0);
        }

        Map<String, Double> sumTimeByAlignment = new HashMap<>();
        Map<String, Long> countByAlignment = new HashMap<>();
        for (AlignmentStatus align : AlignmentStatus.values()) {
            sumTimeByAlignment.put(align.getDisplayName(), 0.0);
            countByAlignment.put(align.getDisplayName(), 0L);
        }

        List<Map<String, Double>> temperatureEfficiencyPoints = new ArrayList<>();
        Map<String, Long> sessionsOverTime = new TreeMap<>();

        Map<String, Double> energyBySource = new LinkedHashMap<>();
        Map<String, Long> sessionsBySource = new LinkedHashMap<>();
        for (EnergySource src : EnergySource.values()) {
            energyBySource.put(src.getDisplayName(), 0.0);
            sessionsBySource.put(src.getDisplayName(), 0L);
        }

        List<Double> allStartBatteries = new ArrayList<>();
        List<Double> allTemperatures = new ArrayList<>();
        List<Double> completedDurations = new ArrayList<>();
        List<Double> completedEnergies = new ArrayList<>();
        List<Double> completedEfficiencies = new ArrayList<>();

        for (ChargingSession session : allSessions) {
            ChargingStatus status = session.getStatus();
            String statusName = status.getDisplayName();
            statusCounts.put(statusName, statusCounts.getOrDefault(statusName, 0L) + 1L);

            String evName = session.getVehicleType().getDisplayName();
            energyByEvType.put(evName, roundThreeDecimals(energyByEvType.getOrDefault(evName, 0.0) + session.getEnergyConsumedKwh()));

            String alignName = session.getAlignmentStatus().getDisplayName();
            sumTimeByAlignment.put(alignName, sumTimeByAlignment.getOrDefault(alignName, 0.0) + session.getChargingTimeMin());
            countByAlignment.put(alignName, countByAlignment.getOrDefault(alignName, 0L) + 1L);

            String srcName = session.getEnergySource().getDisplayName();
            energyBySource.put(srcName, roundThreeDecimals(energyBySource.getOrDefault(srcName, 0.0) + session.getEnergyConsumedKwh()));
            sessionsBySource.put(srcName, sessionsBySource.getOrDefault(srcName, 0L) + 1L);

            if (session.getSessionTimestamp() != null) {
                String dateKey = session.getSessionTimestamp().format(DATE_BUCKET_FORMATTER);
                sessionsOverTime.put(dateKey, sessionsOverTime.getOrDefault(dateKey, 0L) + 1L);
            }

            allStartBatteries.add((double) session.getStartBatteryPct());
            allTemperatures.add(session.getTemperatureC());

            if (status.isSuccessful()) {
                completedSessions++;
                completedDurations.add(session.getChargingTimeMin());
                completedEnergies.add(session.getEnergyConsumedKwh());
                completedEfficiencies.add(session.getChargingEfficiencyPct());

                Map<String, Double> point = new LinkedHashMap<>();
                point.put("x", roundOneDecimal(session.getTemperatureC()));
                point.put("y", roundTwoDecimals(session.getChargingEfficiencyPct()));
                temperatureEfficiencyPoints.add(point);
            }
        }

        Map<String, Double> avgTimeByAlignment = new LinkedHashMap<>();
        for (AlignmentStatus align : AlignmentStatus.values()) {
            String key = align.getDisplayName();
            long cnt = countByAlignment.getOrDefault(key, 0L);
            double avg = cnt > 0 ? roundOneDecimal(sumTimeByAlignment.get(key) / cnt) : 0.0;
            avgTimeByAlignment.put(key, avg);
        }

        List<DescriptiveStatsDto> descriptiveStats = new ArrayList<>();
        descriptiveStats.add(computeDescriptiveStats("Starting Battery Level (All Sessions)", "%", allStartBatteries));
        descriptiveStats.add(computeDescriptiveStats("Simulated Temperature (All Sessions)", "°C", allTemperatures));
        descriptiveStats.add(computeDescriptiveStats("Charging Duration (Completed Sessions)", "min", completedDurations));
        descriptiveStats.add(computeDescriptiveStats("Energy Consumed from Source (Completed)", "kWh", completedEnergies));
        descriptiveStats.add(computeDescriptiveStats("Wireless Charging Efficiency (Completed)", "%", completedEfficiencies));

        return new AnalyticsSummaryDto(
                totalSessions,
                completedSessions,
                statusCounts,
                energyByEvType,
                avgTimeByAlignment,
                temperatureEfficiencyPoints,
                sessionsOverTime,
                energyBySource,
                sessionsBySource,
                descriptiveStats
        );
    }

    /**
     * Computes Count, Mean, Minimum, Maximum, and Standard Deviation for a list of values.
     */
    public DescriptiveStatsDto computeDescriptiveStats(String metricName, String unit, List<Double> values) {
        if (values == null || values.isEmpty()) {
            return new DescriptiveStatsDto(metricName, unit, 0, 0.0, 0.0, 0.0, 0.0);
        }

        int n = values.size();
        double sum = 0.0;
        double min = Double.MAX_VALUE;
        double max = -Double.MAX_VALUE;

        for (double v : values) {
            sum += v;
            if (v < min) {
                min = v;
            }
            if (v > max) {
                max = v;
            }
        }

        double mean = sum / n;
        double sumSquaredDiff = 0.0;
        for (double v : values) {
            double diff = v - mean;
            sumSquaredDiff += diff * diff;
        }

        // Sample standard deviation (or 0 when n <= 1)
        double variance = (n > 1) ? (sumSquaredDiff / (n - 1)) : 0.0;
        double stdDev = Math.sqrt(variance);

        return new DescriptiveStatsDto(
                metricName,
                unit,
                n,
                roundTwoDecimals(mean),
                roundTwoDecimals(min),
                roundTwoDecimals(max),
                roundTwoDecimals(stdDev)
        );
    }

    private double roundOneDecimal(double val) {
        return Math.round(val * 10.0) / 10.0;
    }

    private double roundTwoDecimals(double val) {
        return Math.round(val * 100.0) / 100.0;
    }

    private double roundThreeDecimals(double val) {
        return Math.round(val * 1000.0) / 1000.0;
    }
}
