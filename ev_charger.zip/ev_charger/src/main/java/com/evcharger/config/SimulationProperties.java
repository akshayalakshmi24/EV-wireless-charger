package com.evcharger.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Configurable mathematical and physical simulation parameters for the
 * Auto-Trigger Portable Wireless EV Charger demonstration model.
 *
 * <p>All values represent transparent software simulation parameters rather
 * than certified hardware safety thresholds.</p>
 */
@Component
@ConfigurationProperties(prefix = "evcharger.simulation")
public class SimulationProperties {

    /**
     * Maximum safe simulated temperature (Celsius) before charging is blocked.
     */
    private double maxTemperatureC = 45.0;

    /**
     * Simulated temperature threshold (Celsius) that triggers a thermal warning.
     */
    private double warningTemperatureC = 40.0;

    /**
     * Minimum plausible simulated ambient temperature (Celsius).
     */
    private double minTemperatureC = -10.0;

    /**
     * Nominal battery capacity (kWh) for simulated 2-Wheeler EVs.
     */
    private double twoWheelerCapacityKwh = 3.2;

    /**
     * Nominal battery capacity (kWh) for simulated 3-Wheeler EVs.
     */
    private double threeWheelerCapacityKwh = 7.5;

    /**
     * Nominal wireless charger output power rating (kW).
     */
    private double nominalChargerPowerKw = 3.3;

    /**
     * Base wireless inductive coupling efficiency (%) under Good alignment at reference temperature.
     */
    private double baseWirelessEfficiencyPct = 91.5;

    /**
     * Efficiency reduction (% per degree Celsius above 25 C).
     */
    private double thermalDeratingPctPerC = 0.22;

    /**
     * Efficiency modifier (%) when using direct Solar DC-DC stage.
     */
    private double solarEfficiencyBonusPct = 0.8;

    /**
     * Efficiency modifier (%) when using Hybrid Solar + Grid power stage.
     */
    private double hybridEfficiencyBonusPct = 0.5;

    /**
     * Repeatable random seed for generating synthetic EDA demo records.
     */
    private long demoRandomSeed = 42L;

    /**
     * Whether to seed initial sample records when the database is empty on startup.
     */
    private boolean seedInitialDataOnStartup = true;

    public SimulationProperties() {
    }

    public double getMaxTemperatureC() {
        return maxTemperatureC;
    }

    public void setMaxTemperatureC(double maxTemperatureC) {
        this.maxTemperatureC = maxTemperatureC;
    }

    public double getWarningTemperatureC() {
        return warningTemperatureC;
    }

    public void setWarningTemperatureC(double warningTemperatureC) {
        this.warningTemperatureC = warningTemperatureC;
    }

    public double getMinTemperatureC() {
        return minTemperatureC;
    }

    public void setMinTemperatureC(double minTemperatureC) {
        this.minTemperatureC = minTemperatureC;
    }

    public double getTwoWheelerCapacityKwh() {
        return twoWheelerCapacityKwh;
    }

    public void setTwoWheelerCapacityKwh(double twoWheelerCapacityKwh) {
        this.twoWheelerCapacityKwh = twoWheelerCapacityKwh;
    }

    public double getThreeWheelerCapacityKwh() {
        return threeWheelerCapacityKwh;
    }

    public void setThreeWheelerCapacityKwh(double threeWheelerCapacityKwh) {
        this.threeWheelerCapacityKwh = threeWheelerCapacityKwh;
    }

    public double getNominalChargerPowerKw() {
        return nominalChargerPowerKw;
    }

    public void setNominalChargerPowerKw(double nominalChargerPowerKw) {
        this.nominalChargerPowerKw = nominalChargerPowerKw;
    }

    public double getBaseWirelessEfficiencyPct() {
        return baseWirelessEfficiencyPct;
    }

    public void setBaseWirelessEfficiencyPct(double baseWirelessEfficiencyPct) {
        this.baseWirelessEfficiencyPct = baseWirelessEfficiencyPct;
    }

    public double getThermalDeratingPctPerC() {
        return thermalDeratingPctPerC;
    }

    public void setThermalDeratingPctPerC(double thermalDeratingPctPerC) {
        this.thermalDeratingPctPerC = thermalDeratingPctPerC;
    }

    public double getSolarEfficiencyBonusPct() {
        return solarEfficiencyBonusPct;
    }

    public void setSolarEfficiencyBonusPct(double solarEfficiencyBonusPct) {
        this.solarEfficiencyBonusPct = solarEfficiencyBonusPct;
    }

    public double getHybridEfficiencyBonusPct() {
        return hybridEfficiencyBonusPct;
    }

    public void setHybridEfficiencyBonusPct(double hybridEfficiencyBonusPct) {
        this.hybridEfficiencyBonusPct = hybridEfficiencyBonusPct;
    }

    public long getDemoRandomSeed() {
        return demoRandomSeed;
    }

    public void setDemoRandomSeed(long demoRandomSeed) {
        this.demoRandomSeed = demoRandomSeed;
    }

    public boolean isSeedInitialDataOnStartup() {
        return seedInitialDataOnStartup;
    }

    public void setSeedInitialDataOnStartup(boolean seedInitialDataOnStartup) {
        this.seedInitialDataOnStartup = seedInitialDataOnStartup;
    }
}
