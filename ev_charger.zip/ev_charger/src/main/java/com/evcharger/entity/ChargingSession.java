package com.evcharger.entity;

import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.EnergySource;
import com.evcharger.model.VehicleType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * JPA Entity representing a persistent EV wireless charging session record
 * stored in the local H2 database.
 *
 * <p>Stores both completed sessions and blocked/failed attempts so that
 * operational reliability, coil alignment issues, and thermal cutoffs
 * can be analyzed in the dashboard and exported to CSV for Python EDA.</p>
 */
@Entity
@Table(name = "charging_sessions")
public class ChargingSession {

    private static final DateTimeFormatter DISPLAY_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "session_id")
    private Long sessionId;

    @Column(name = "ev_id", nullable = false, length = 40)
    private String evId;

    @Enumerated(EnumType.STRING)
    @Column(name = "vehicle_type", nullable = false, length = 25)
    private VehicleType vehicleType;

    @Column(name = "start_battery_pct", nullable = false)
    private int startBatteryPct;

    @Column(name = "target_battery_pct", nullable = false)
    private int targetBatteryPct;

    @Column(name = "end_battery_pct", nullable = false)
    private int endBatteryPct;

    @Column(name = "temperature_c", nullable = false)
    private double temperatureC;

    @Enumerated(EnumType.STRING)
    @Column(name = "alignment_status", nullable = false, length = 20)
    private AlignmentStatus alignmentStatus;

    @Column(name = "charging_time_min", nullable = false)
    private double chargingTimeMin;

    @Column(name = "energy_delivered_kwh", nullable = false)
    private double energyDeliveredKwh;

    @Column(name = "energy_consumed_kwh", nullable = false)
    private double energyConsumedKwh;

    @Column(name = "charging_efficiency_pct", nullable = false)
    private double chargingEfficiencyPct;

    @Enumerated(EnumType.STRING)
    @Column(name = "energy_source", nullable = false, length = 25)
    private EnergySource energySource;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 35)
    private ChargingStatus status;

    @Column(name = "status_message", length = 600)
    private String statusMessage;

    @Column(name = "synthetic_demo", nullable = false)
    private boolean syntheticDemo;

    @Column(name = "session_timestamp", nullable = false)
    private LocalDateTime sessionTimestamp;

    public ChargingSession() {
        this.sessionTimestamp = LocalDateTime.now();
    }

    public ChargingSession(String evId,
                           VehicleType vehicleType,
                           int startBatteryPct,
                           int targetBatteryPct,
                           int endBatteryPct,
                           double temperatureC,
                           AlignmentStatus alignmentStatus,
                           double chargingTimeMin,
                           double energyDeliveredKwh,
                           double energyConsumedKwh,
                           double chargingEfficiencyPct,
                           EnergySource energySource,
                           ChargingStatus status,
                           String statusMessage,
                           boolean syntheticDemo,
                           LocalDateTime sessionTimestamp) {
        this.evId = evId;
        this.vehicleType = vehicleType;
        this.startBatteryPct = startBatteryPct;
        this.targetBatteryPct = targetBatteryPct;
        this.endBatteryPct = endBatteryPct;
        this.temperatureC = temperatureC;
        this.alignmentStatus = alignmentStatus;
        this.chargingTimeMin = chargingTimeMin;
        this.energyDeliveredKwh = energyDeliveredKwh;
        this.energyConsumedKwh = energyConsumedKwh;
        this.chargingEfficiencyPct = chargingEfficiencyPct;
        this.energySource = energySource;
        this.status = status;
        this.statusMessage = statusMessage;
        this.syntheticDemo = syntheticDemo;
        this.sessionTimestamp = sessionTimestamp != null ? sessionTimestamp : LocalDateTime.now();
    }

    public String getFormattedTimestamp() {
        return sessionTimestamp != null ? sessionTimestamp.format(DISPLAY_FORMATTER) : "";
    }

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    public String getEvId() {
        return evId;
    }

    public void setEvId(String evId) {
        this.evId = evId;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getStartBatteryPct() {
        return startBatteryPct;
    }

    public void setStartBatteryPct(int startBatteryPct) {
        this.startBatteryPct = startBatteryPct;
    }

    public int getTargetBatteryPct() {
        return targetBatteryPct;
    }

    public void setTargetBatteryPct(int targetBatteryPct) {
        this.targetBatteryPct = targetBatteryPct;
    }

    public int getEndBatteryPct() {
        return endBatteryPct;
    }

    public void setEndBatteryPct(int endBatteryPct) {
        this.endBatteryPct = endBatteryPct;
    }

    public double getTemperatureC() {
        return temperatureC;
    }

    public void setTemperatureC(double temperatureC) {
        this.temperatureC = temperatureC;
    }

    public AlignmentStatus getAlignmentStatus() {
        return alignmentStatus;
    }

    public void setAlignmentStatus(AlignmentStatus alignmentStatus) {
        this.alignmentStatus = alignmentStatus;
    }

    public double getChargingTimeMin() {
        return chargingTimeMin;
    }

    public void setChargingTimeMin(double chargingTimeMin) {
        this.chargingTimeMin = chargingTimeMin;
    }

    public double getEnergyDeliveredKwh() {
        return energyDeliveredKwh;
    }

    public void setEnergyDeliveredKwh(double energyDeliveredKwh) {
        this.energyDeliveredKwh = energyDeliveredKwh;
    }

    public double getEnergyConsumedKwh() {
        return energyConsumedKwh;
    }

    public void setEnergyConsumedKwh(double energyConsumedKwh) {
        this.energyConsumedKwh = energyConsumedKwh;
    }

    public double getChargingEfficiencyPct() {
        return chargingEfficiencyPct;
    }

    public void setChargingEfficiencyPct(double chargingEfficiencyPct) {
        this.chargingEfficiencyPct = chargingEfficiencyPct;
    }

    public EnergySource getEnergySource() {
        return energySource;
    }

    public void setEnergySource(EnergySource energySource) {
        this.energySource = energySource;
    }

    public ChargingStatus getStatus() {
        return status;
    }

    public void setStatus(ChargingStatus status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public boolean isSyntheticDemo() {
        return syntheticDemo;
    }

    public void setSyntheticDemo(boolean syntheticDemo) {
        this.syntheticDemo = syntheticDemo;
    }

    public LocalDateTime getSessionTimestamp() {
        return sessionTimestamp;
    }

    public void setSessionTimestamp(LocalDateTime sessionTimestamp) {
        this.sessionTimestamp = sessionTimestamp;
    }
}
