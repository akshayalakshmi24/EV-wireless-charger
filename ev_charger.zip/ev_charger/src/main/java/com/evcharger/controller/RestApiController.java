package com.evcharger.controller;

import com.evcharger.dto.AnalyticsSummaryDto;
import com.evcharger.dto.ChargingSessionRequestDto;
import com.evcharger.dto.DashboardSummaryDto;
import com.evcharger.entity.ChargingSession;
import com.evcharger.service.CSVExportService;
import com.evcharger.service.ChargingService;
import com.evcharger.service.DashboardService;
import com.evcharger.service.SessionDataService;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * REST API Controller exposing JSON and CSV endpoints for programmatic access,
 * automated testing, and external Python/Streamlit integration.
 */
@RestController
@RequestMapping("/api")
public class RestApiController {

    private final ChargingService chargingService;
    private final SessionDataService sessionDataService;
    private final DashboardService dashboardService;
    private final CSVExportService csvExportService;

    public RestApiController(ChargingService chargingService,
                             SessionDataService sessionDataService,
                             DashboardService dashboardService,
                             CSVExportService csvExportService) {
        this.chargingService = chargingService;
        this.sessionDataService = sessionDataService;
        this.dashboardService = dashboardService;
        this.csvExportService = csvExportService;
    }

    @GetMapping("/sessions")
    public List<ChargingSession> getAllSessions() {
        return sessionDataService.getAllSessionsNewestFirst();
    }

    @GetMapping("/sessions/{id}")
    public ChargingSession getSessionById(@PathVariable("id") Long id) {
        return sessionDataService.getSessionById(id);
    }

    @PostMapping("/sessions")
    public ResponseEntity<Map<String, Object>> triggerSessionApi(@Valid @RequestBody ChargingSessionRequestDto requestDto) {
        ChargingService.SessionExecutionOutcome outcome =
                chargingService.detectAndTriggerCharging(requestDto);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("session", outcome.getSession());
        response.put("workflowLogs", outcome.getCalculationResult().getWorkflowLogs());
        response.put("temperatureWarning", outcome.getCalculationResult().isTemperatureWarning());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/dashboard")
    public DashboardSummaryDto getDashboardSummary() {
        return dashboardService.buildDashboardSummary();
    }

    @GetMapping("/analytics")
    public AnalyticsSummaryDto getAnalyticsSummary() {
        return dashboardService.buildAnalyticsSummary();
    }

    @GetMapping("/export/csv")
    public ResponseEntity<byte[]> exportCsvApi() {
        String csv = csvExportService.exportAllSessionsToCsvString();
        byte[] bytes = csv.getBytes(StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"ev_charging_sessions.csv\"")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(bytes);
    }
}
