package com.evcharger.controller;

import com.evcharger.config.SimulationProperties;
import com.evcharger.dto.AnalyticsSummaryDto;
import com.evcharger.dto.ChargingSessionRequestDto;
import com.evcharger.dto.DashboardSummaryDto;
import com.evcharger.entity.ChargingSession;
import com.evcharger.model.AlignmentStatus;
import com.evcharger.model.ChargingStatus;
import com.evcharger.model.EnergySource;
import com.evcharger.model.VehicleType;
import com.evcharger.service.CSVExportService;
import com.evcharger.service.ChargingService;
import com.evcharger.service.DashboardService;
import com.evcharger.service.SessionDataService;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.List;

/**
 * Spring MVC Controller serving all 5 pages of the Auto-Trigger Portable Wireless EV Charger
 * web management interface:
 * <ul>
 *     <li>Page 1: Dashboard ({@code /})</li>
 *     <li>Page 2: New Charging Session ({@code /session/new})</li>
 *     <li>Page 3: Charging History &amp; Session Details ({@code /history}, {@code /history/{id}})</li>
 *     <li>Page 4: Analytics ({@code /analytics})</li>
 *     <li>Page 5: Data Export ({@code /export}, {@code /export/csv})</li>
 * </ul>
 */
@Controller
public class WebDashboardController {

    private final ChargingService chargingService;
    private final SessionDataService sessionDataService;
    private final DashboardService dashboardService;
    private final CSVExportService csvExportService;
    private final SimulationProperties simulationProperties;

    public WebDashboardController(ChargingService chargingService,
                                  SessionDataService sessionDataService,
                                  DashboardService dashboardService,
                                  CSVExportService csvExportService,
                                  SimulationProperties simulationProperties) {
        this.chargingService = chargingService;
        this.sessionDataService = sessionDataService;
        this.dashboardService = dashboardService;
        this.csvExportService = csvExportService;
        this.simulationProperties = simulationProperties;
    }

    /**
     * Page 1: Dashboard view displaying KPIs, recent sessions, and summary charts.
     */
    @GetMapping({"/", "/dashboard"})
    public String showDashboard(Model model) {
        DashboardSummaryDto summary = dashboardService.buildDashboardSummary();
        List<ChargingSession> recentSessions = sessionDataService.getRecentSessionsForDashboard();

        model.addAttribute("activePage", "dashboard");
        model.addAttribute("summary", summary);
        model.addAttribute("recentSessions", recentSessions);
        model.addAttribute("simProps", simulationProperties);
        return "dashboard";
    }

    /**
     * Page 2 (GET): New Charging Session simulation form.
     */
    @GetMapping("/session/new")
    public String showNewSessionForm(Model model) {
        if (!model.containsAttribute("sessionRequest")) {
            model.addAttribute("sessionRequest", new ChargingSessionRequestDto());
        }
        populateNewSessionReferenceData(model);
        return "new-session";
    }

    /**
     * Page 2 (POST): Validates form input, triggers simulated EV detection &amp; charging checks,
     * persists the session record, and displays the workflow logs and result.
     */
    @PostMapping("/session/new")
    public String processNewSession(@Valid @ModelAttribute("sessionRequest") ChargingSessionRequestDto sessionRequest,
                                    BindingResult bindingResult,
                                    Model model) {
        populateNewSessionReferenceData(model);

        if (bindingResult.hasErrors()) {
            model.addAttribute("validationError",
                    "Please correct the highlighted form errors before starting the simulation.");
            return "new-session";
        }

        ChargingService.SessionExecutionOutcome outcome =
                chargingService.detectAndTriggerCharging(sessionRequest);

        model.addAttribute("executionOutcome", outcome);
        model.addAttribute("savedSession", outcome.getSession());
        model.addAttribute("calcResult", outcome.getCalculationResult());
        return "new-session";
    }

    /**
     * Page 3: Charging History table with search, filters, and column sorting.
     */
    @GetMapping("/history")
    public String showChargingHistory(@RequestParam(name = "q", defaultValue = "") String searchQuery,
                                      @RequestParam(name = "vehicleType", defaultValue = "ALL") String vehicleType,
                                      @RequestParam(name = "status", defaultValue = "ALL") String status,
                                      @RequestParam(name = "alignment", defaultValue = "ALL") String alignment,
                                      @RequestParam(name = "sortBy", defaultValue = "timestamp") String sortBy,
                                      @RequestParam(name = "sortDir", defaultValue = "desc") String sortDir,
                                      Model model) {
        List<ChargingSession> sessions = sessionDataService.searchAndSortSessions(
                searchQuery, vehicleType, status, alignment, sortBy, sortDir
        );

        model.addAttribute("activePage", "history");
        model.addAttribute("sessions", sessions);
        model.addAttribute("searchQuery", searchQuery);
        model.addAttribute("selectedVehicleType", vehicleType);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("selectedAlignment", alignment);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("vehicleTypes", VehicleType.values());
        model.addAttribute("chargingStatuses", ChargingStatus.values());
        model.addAttribute("alignmentStatuses", AlignmentStatus.values());
        return "history";
    }

    /**
     * Page 3 (Detail View): Detailed inspection page for a single ChargingSession.
     */
    @GetMapping("/history/{id}")
    public String showSessionDetail(@PathVariable("id") Long sessionId, Model model) {
        ChargingSession session = sessionDataService.getSessionById(sessionId);
        model.addAttribute("activePage", "history");
        model.addAttribute("record", session);
        model.addAttribute("simProps", simulationProperties);
        return "session-detail";
    }

    /**
     * Page 4: Interactive Analytics &amp; Descriptive Statistics page.
     */
    @GetMapping("/analytics")
    public String showAnalytics(Model model) {
        AnalyticsSummaryDto analytics = dashboardService.buildAnalyticsSummary();
        model.addAttribute("activePage", "analytics");
        model.addAttribute("analytics", analytics);
        model.addAttribute("simProps", simulationProperties);
        return "analytics";
    }

    /**
     * Page 5: Data Export page with CSV preview and Python EDA instructions.
     */
    @GetMapping("/export")
    public String showExportPage(Model model) {
        List<ChargingSession> allSessions = sessionDataService.getAllSessionsChronological();
        String csvPreview = csvExportService.generateCsvContent(
                allSessions.size() > 8 ? allSessions.subList(0, 8) : allSessions
        );

        model.addAttribute("activePage", "export");
        model.addAttribute("totalRecords", allSessions.size());
        model.addAttribute("syntheticCount", sessionDataService.countSyntheticDemoSessions());
        model.addAttribute("csvHeader", CSVExportService.CSV_HEADER);
        model.addAttribute("csvPreview", csvPreview);
        return "export";
    }

    /**
     * Page 5 (Download): Streams the complete CSV dataset to the browser and also saves
     * a local copy to {@code ./data/ev_charging_sessions_export.csv}.
     */
    @GetMapping("/export/csv")
    public ResponseEntity<byte[]> downloadCsvExport() {
        String csvContent = csvExportService.exportAllSessionsToCsvString();
        try {
            csvExportService.writeSessionsToCsvFile(Paths.get("data", "ev_charging_sessions_export.csv"));
        } catch (Exception ignored) {
            // Non-fatal if working directory is read-only; HTTP response still streams CSV
        }

        byte[] csvBytes = csvContent.getBytes(StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"ev_charging_sessions.csv\"")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .contentLength(csvBytes.length)
                .body(csvBytes);
    }

    /**
     * Generates 100 reproducible synthetic demo charging sessions for Python EDA.
     * Prevents accidental duplicate accumulation by checking existing demo count and
     * refreshing the 100-session synthetic batch cleanly.
     */
    @PostMapping("/demo/generate")
    public String generateDemoData(@RequestParam(name = "forceReplace", defaultValue = "false") boolean forceReplace,
                                   @RequestParam(name = "redirectTo", defaultValue = "/") String redirectTo,
                                   RedirectAttributes redirectAttributes) {
        long existingSynthetic = sessionDataService.countSyntheticDemoSessions();
        if (existingSynthetic >= 100 && !forceReplace) {
            redirectAttributes.addFlashAttribute("demoWarningMessage",
                    "100 synthetic demo sessions are already present in the database. " +
                    "Click 'Regenerate Fresh 100 Demo Batch' to reset and regenerate them without duplicates.");
            redirectAttributes.addFlashAttribute("promptForceReplace", true);
            return "redirect:" + sanitizeRedirect(redirectTo);
        }

        int generatedCount = sessionDataService.generateReproducibleDemoSessions(100, true);
        redirectAttributes.addFlashAttribute("demoSuccessMessage",
                "Successfully generated " + generatedCount + " reproducible synthetic demo charging sessions (Seed = "
                        + simulationProperties.getDemoRandomSeed() + ") for Python EDA.");
        return "redirect:" + sanitizeRedirect(redirectTo);
    }

    private void populateNewSessionReferenceData(Model model) {
        model.addAttribute("activePage", "new-session");
        model.addAttribute("vehicleTypes", VehicleType.values());
        model.addAttribute("alignmentStatuses", AlignmentStatus.values());
        model.addAttribute("energySources", EnergySource.values());
        model.addAttribute("simProps", simulationProperties);
    }

    private String sanitizeRedirect(String redirectTo) {
        if (redirectTo == null || !redirectTo.startsWith("/")) {
            return "/";
        }
        return redirectTo;
    }
}
