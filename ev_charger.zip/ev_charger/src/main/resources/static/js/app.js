/**
 * AUTO-TRIGGER PORTABLE WIRELESS EV CHARGER
 * Frontend Interactive Helpers & Chart.js Dark Navy Theme Configuration
 */

document.addEventListener("DOMContentLoaded", function () {
    if (typeof Chart !== "undefined") {
        Chart.defaults.color = "#94a3b8";
        Chart.defaults.borderColor = "rgba(36, 54, 94, 0.65)";
        Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    }
});

/**
 * Populates the New Charging Session form with realistic demonstration scenarios
 * so evaluators can test valid, thermal-warning, and blocked conditions in one click.
 */
function applyScenarioPreset(preset) {
    const evIdInput = document.getElementById("evId");
    const vehicleTypeSelect = document.getElementById("vehicleType");
    const startBatteryInput = document.getElementById("startBatteryPct");
    const targetBatteryInput = document.getElementById("targetBatteryPct");
    const temperatureInput = document.getElementById("temperatureC");
    const alignmentSelect = document.getElementById("alignmentStatus");
    const energySourceSelect = document.getElementById("energySource");

    if (!evIdInput) {
        return;
    }

    switch (preset) {
        case "valid2w":
            evIdInput.value = "EV-2W-205";
            vehicleTypeSelect.value = "TWO_WHEELER";
            startBatteryInput.value = 22;
            targetBatteryInput.value = 85;
            temperatureInput.value = 29.5;
            alignmentSelect.value = "GOOD";
            energySourceSelect.value = "SOLAR_GRID";
            break;

        case "valid3wWarn":
            evIdInput.value = "EV-3W-318";
            vehicleTypeSelect.value = "THREE_WHEELER";
            startBatteryInput.value = 30;
            targetBatteryInput.value = 90;
            temperatureInput.value = 42.0; // Triggers thermal warning (>= 40 C, <= 45 C)
            alignmentSelect.value = "GOOD";
            energySourceSelect.value = "SOLAR";
            break;

        case "poorAlignment":
            evIdInput.value = "EV-2W-409";
            vehicleTypeSelect.value = "TWO_WHEELER";
            startBatteryInput.value = 35;
            targetBatteryInput.value = 80;
            temperatureInput.value = 31.0;
            alignmentSelect.value = "POOR"; // Blocks charging due to poor coil alignment
            energySourceSelect.value = "GRID";
            break;

        case "highTempBlock":
            evIdInput.value = "EV-3W-512";
            vehicleTypeSelect.value = "THREE_WHEELER";
            startBatteryInput.value = 18;
            targetBatteryInput.value = 85;
            temperatureInput.value = 48.5; // Exceeds 45.0 C threshold -> Blocks charging
            alignmentSelect.value = "GOOD";
            energySourceSelect.value = "GRID";
            break;

        case "invalidBattery":
            evIdInput.value = "EV-2W-601";
            vehicleTypeSelect.value = "TWO_WHEELER";
            startBatteryInput.value = 80;
            targetBatteryInput.value = 60; // Target <= Start -> Blocked
            temperatureInput.value = 28.0;
            alignmentSelect.value = "GOOD";
            energySourceSelect.value = "SOLAR";
            break;
    }
}
